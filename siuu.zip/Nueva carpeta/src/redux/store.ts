import { configureStore, ThunkAction, Action } from "@reduxjs/toolkit";
import { filterReducer } from "./slices/actualFilterSlice/actualFilterSlice";
import { devicesReducer } from "./slices/devices/devicesSlice";
import { filteredDevicesReducer } from "./slices/devices/filteredDevicesSlice";
import { uiDataReducer } from "./slices/uiSlice/uiSlice";

export const store = configureStore({
  reducer: {
    devices: devicesReducer,
    filteredDevices: filteredDevicesReducer,
    ui: uiDataReducer,
    actualFilter: filterReducer,
  },
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
