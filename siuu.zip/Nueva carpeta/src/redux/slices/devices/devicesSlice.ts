import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Devices, Lamp } from "../../../types/interfaces";

const initialDevices: Devices = {
  gateways: [],
  nodes: [],
};

const devicesSlice = createSlice({
  name: "devices",
  initialState: initialDevices,
  reducers: {
    loadAllDevices: (previousState, action: PayloadAction<Devices>) => ({
      ...action.payload,
    }),
    updateNodeDeviceStatusGlobal: (
      previousState,
      action: PayloadAction<Lamp>
    ) => {
      const nodeToUpdate = previousState.nodes.findIndex(
        (node) => node.uid === action.payload.uid
      );

      previousState.nodes.forEach((node, index) => {
        if (index === nodeToUpdate) {
          node.on = action.payload.on;
        }
      });
    },
  },
});

export const devicesReducer = devicesSlice.reducer;

export const {
  loadAllDevices: loadDevicesActionCreator,
  updateNodeDeviceStatusGlobal: updateNodeDeviceStatusGlobalActionCreator,
} = devicesSlice.actions;
