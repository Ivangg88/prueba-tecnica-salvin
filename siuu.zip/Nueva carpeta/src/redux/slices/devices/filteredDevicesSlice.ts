import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Devices, Lamp } from "../../../types/interfaces";

const initialDevices: Devices = {
  gateways: [],
  nodes: [],
};

const filteredDevicesSlice = createSlice({
  name: "filteredDevices",
  initialState: initialDevices,
  reducers: {
    filteredAllDevices: (previousState, action: PayloadAction<Devices>) => ({
      ...action.payload,
    }),

    filterOnDevices: (previousState, action: PayloadAction<Devices>) => ({
      ...previousState,
      nodes: action.payload.nodes.filter((node) => node.online && node.on),
    }),
    filterOffDevices: (previousState, action: PayloadAction<Devices>) => ({
      ...previousState,
      nodes: action.payload.nodes.filter((node) => node.online && !node.on),
    }),
    filterDiconnectedDevices: (
      previousState,
      action: PayloadAction<Devices>
    ) => ({
      ...previousState,
      nodes: action.payload.nodes.filter((node) => !node.online),
    }),
    filterAlarmDevices: (previousState, action: PayloadAction<Devices>) => ({
      ...previousState,
      nodes: action.payload.nodes.filter((node) => node.alarm_status),
    }),
    filterByProjectName: (previousState, action: PayloadAction<string>) => ({
      ...previousState,
      nodes: previousState.nodes.filter((node) =>
        action.payload === "All" ? node : node.prjName === action.payload
      ),
    }),

    filterByArea: (previousState, action: PayloadAction<Lamp[]>) => ({
      ...previousState,
      nodes: action.payload,
    }),

    updateNodeDeviceStatus: (previousState, action: PayloadAction<Lamp>) => {
      const nodeToUpdate = previousState.nodes.findIndex(
        (node) => node.uid === action.payload.uid
      );

      previousState.nodes.forEach((node, index) => {
        if (index === nodeToUpdate) {
          node.on = action.payload.on;
        }
      });
    },
  },
});

export const filteredDevicesReducer = filteredDevicesSlice.reducer;

export const {
  filterOnDevices: filterOnDevicesActionCreator,
  filterOffDevices: filterOffDevicesActionCreator,
  filterAlarmDevices: filterAlarmDevicesActionCreator,
  filterDiconnectedDevices: filterDiconnectedDevicesActionCretor,
  filteredAllDevices: filteredAllDevicesActionCreator,
  filterByProjectName: filterByProjectNameActionCreator,
  updateNodeDeviceStatus: updateNodeDeviceStatusFiltered,
  filterByArea: filterByAreaActionCreator,
} = filteredDevicesSlice.actions;
