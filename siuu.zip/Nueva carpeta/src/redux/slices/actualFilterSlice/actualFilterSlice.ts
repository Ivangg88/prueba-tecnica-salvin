import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { DevicesFilter } from "../../../types/interfaces";

const initialState: DevicesFilter = {
  all: true,
  alarmas: false,
  on: false,
  off: false,
  disconnected: false,
};
const filterSlice = createSlice({
  name: "actualFilter",
  initialState: initialState,
  reducers: {
    setActualFilter: (previousData, action: PayloadAction<DevicesFilter>) => ({
      ...action.payload,
    }),
  },
});

export const filterReducer = filterSlice.reducer;

export const { setActualFilter: setActualFilterActionCreator } =
  filterSlice.actions;
