import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { NodeDevice, UiData } from "../../../types/interfaces";
import { getAllpositions } from "../../../utils/auxiliaryFunctions";
import { Language } from "../../../utils/languages/languages";

const uiDataInitialState: UiData = {
  isLoading: false,
  actualLanguage: "english",
  selectedBoundsToFly: {
    northEast: { latitude: 0, longitude: 0 },
    southWest: { latitude: 0, longitude: 0 },
  },
  allowFlyMode: true,
};

const uiDataSlice = createSlice({
  name: "uiData",
  initialState: uiDataInitialState,
  reducers: {
    openLoadingModal: (previousUiData: UiData) => ({
      ...previousUiData,
      isLoading: true,
    }),

    closeLoadingModal: (previousUiData: UiData) => ({
      ...previousUiData,
      isLoading: false,
    }),

    setActualLanguage: (previousUiData, action: PayloadAction<Language>) => ({
      ...previousUiData,
      actualLanguage: action.payload,
    }),

    setBoundsToFly: (
      previousData,
      action: PayloadAction<Array<NodeDevice>>
    ) => {
      const positions = getAllpositions(action.payload);

      return {
        ...previousData,
        selectedBoundsToFly: {
          northEast: {
            latitude: positions[positions.length - 1].latitude,
            longitude: positions[positions.length - 1].longitude,
          },
          southWest: {
            latitude: positions[0].latitude,
            longitude: positions[0].longitude,
          },
        },
      };
    },

    allowFlyMode: (previousUiData, action: PayloadAction<boolean>) => ({
      ...previousUiData,
      allowFlyMode: action.payload,
    }),
  },
});

export const uiDataReducer = uiDataSlice.reducer;

export const {
  openLoadingModal: openLoadingModalActionCreator,
  closeLoadingModal: closeLoadingModalActionCreator,
  setActualLanguage: setActualLanguageActionCreator,
  setBoundsToFly: setBoundsToFlyActionCreator,
  allowFlyMode: allowFlyModeActionCreator,
} = uiDataSlice.actions;
