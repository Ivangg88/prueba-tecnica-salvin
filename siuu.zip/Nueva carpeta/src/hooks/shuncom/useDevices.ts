import { sender } from "../../components/App/App";
import { useAppDispatch } from "../../redux/hooks";
import {
  loadDevicesActionCreator,
  updateNodeDeviceStatusGlobalActionCreator,
} from "../../redux/slices/devices/devicesSlice";
import {
  filteredAllDevicesActionCreator,
  updateNodeDeviceStatusFiltered,
} from "../../redux/slices/devices/filteredDevicesSlice";
import { Devices, Lamp, NodeDevice } from "../../types/interfaces";

export const useShuncomDevices = () => {
  const dispatch = useAppDispatch();

  const loadDevices = async () => {
    const nodeResponse = await sender.luminaireSearch("");
    const gatewayResponse = await sender.gatewaySearch(1, "");

    const gateways = JSON.parse(gatewayResponse).rows;
    const nodes: Lamp[] = JSON.parse(nodeResponse).rows;

    const devicesNode = nodes.map((node) => {
      const newDevice: NodeDevice = {
        addr: node.addr,
        alarm_id: node.alarm_id,
        alarm_status: node.alarm_status,
        bri: node.bri,
        gateway_addr: node.gateway_addr,
        lamp_ctrl_id: node.lamp_ctrl_id,
        latitude: node.latitude,
        longitude: node.longitude,
        name: node.name,
        on: node.on,
        online: node.online,
        organizationId: node.organizationId,
        orgName: node.orgName,
        pEnergy: node.pEnergy,
        prjName: node.prjName,
        projectId: node.projectId,
        uid: node.uid,
      };

      return newDevice;
    });
    const devices: Devices = {
      gateways,
      nodes: devicesNode,
    };
    console.log("Devices", devices);

    dispatch(loadDevicesActionCreator(devices));
    dispatch(filteredAllDevicesActionCreator(devices));
  };

  const switchNodeStatus = async (order: number, node: NodeDevice) => {
    try {
      await sender.switchOnLuminaires([node], order);
      const response = await sender.luminaireSearch(node.name);
      const foundedNode: NodeDevice = JSON.parse(response).rows[0];
      dispatch(updateNodeDeviceStatusFiltered(foundedNode));
      dispatch(updateNodeDeviceStatusGlobalActionCreator(foundedNode));

      return foundedNode;
    } catch (error: unknown) {
      alert((error as Error).message);
    }
  };

  const switchNodeGroupStatus = async (
    order: number,
    nodes: Array<NodeDevice>
  ) => {
    try {
      await sender.switchOnLuminaires(nodes, order);

      nodes.forEach(async (node) => {
        const response = await sender.luminaireSearch(node.name);
        const foundedNode: NodeDevice = JSON.parse(response).rows[0];
        dispatch(updateNodeDeviceStatusFiltered(foundedNode));
        dispatch(updateNodeDeviceStatusGlobalActionCreator(foundedNode));
      });
    } catch (error: unknown) {
      alert((error as Error).message);
    }
  };

  const dimmingDevices = async (dimming: number, nodes: Array<NodeDevice>) => {
    await sender.dimmingStandardLuminaires(nodes, dimming);
    await switchNodeGroupStatus(1, nodes);

    nodes.forEach(async (node) => {
      const response = await sender.luminaireSearch(node.name);
      const foundedNode: NodeDevice = JSON.parse(response).rows[0];
      dispatch(updateNodeDeviceStatusFiltered(foundedNode));
      dispatch(updateNodeDeviceStatusGlobalActionCreator(foundedNode));
    });
  };
  return {
    loadDevices,
    switchNodeStatus,
    switchNodeGroupStatus,
    dimmingDevices,
  };
};
