import { sender } from "../../components/App/App";
import { useShuncomDevices } from "./useDevices";

export const useLoginShuncom = () => {
  const { loadDevices } = useShuncomDevices();

  const loginUser = async (username: string, password: string) => {
    if (sender.getTokenInterface()) {
      await sender.shuncomLogin(username, password);
      await loadDevices();
    }
  };

  return { loginUser };
};
