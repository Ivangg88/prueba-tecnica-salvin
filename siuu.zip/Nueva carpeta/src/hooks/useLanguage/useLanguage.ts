import { useAppDispatch, useAppSelector } from "../../redux/hooks";
import { setActualLanguageActionCreator } from "../../redux/slices/uiSlice/uiSlice";
import { Language } from "../../utils/languages/languages";

export const useLanguage = () => {
  const dispatch = useAppDispatch();
  const currentLanguage = useAppSelector((state) => state.ui.actualLanguage);

  const setCurrentLanguage = (language: Language = "english") => {
    dispatch(setActualLanguageActionCreator(language));
  };

  return { currentLanguage, setCurrentLanguage };
};
