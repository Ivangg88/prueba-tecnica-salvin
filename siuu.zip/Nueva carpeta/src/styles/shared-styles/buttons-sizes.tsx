import styled from "styled-components";
import { styledMainTheme } from "../styleMainTheme";

export const Button = styled.button`
  padding: 8px 48px;
  border-radius: 20px;
  background-color: ${(props: {
    buttonType: "primary" | "secondary" | "link" | "";
  }) =>
    props.buttonType === "primary"
      ? styledMainTheme.light.buttonMainColor
      : props.buttonType === "secondary"
      ? styledMainTheme?.light?.mainBackgroundColor
      : "red"};
  color: #1b2559;
  font-weight: 500;
  font-size: 14px;
  line-height: 24px;
  outline: none;
  border: none;
`;
