export const credentials = {
  salviAdmin: {
    url: "http://192.168.1.222:8080/CloudPlatform/",
    username: "Smartecadmin",
    password: "Smrt.By_SLV20",
  },

  arsene: {
    url: "http://41.186.195.8:8080/CloudPlatform/",
    username: "arsene_simbi",
    password: "Smartec.2021",
  },

  salviLighting: {
    url: "http://192.168.1.222:8080/CloudPlatform/",
    username: "salviLighting1",
    password: "salviLighting1",
  },
};
