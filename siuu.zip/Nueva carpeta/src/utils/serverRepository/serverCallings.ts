import { CryptoService } from "./cryptoService";
import { ShuncomStruct } from "../../app/models/shuncom-struct";
import { Lamp, NodeDevice } from "../../types/interfaces";

export class serverCallings {
  private webAddressPrefix: string = ""; // "http://192.168.1.222:8080/CloudPlatform/"; // "http://41.186.195.8:8080/CloudPlatform/"; //  // 'http://server-datos.salvi.es:8080/CloudPlatform/'; //
  private operatorID: string = "123456789";
  private privateKey: string = "1234567890abcdef";
  private accessToken: string = "";
  private sessionId: string = "";
  private webAddress: string = "";
  private sequence: number = 0;
  private servicioEncriptacion: CryptoService;
  private structure: ShuncomStruct;

  constructor(url: string) {
    this.webAddressPrefix = url;
    this.servicioEncriptacion = new CryptoService();
    this.accessToken = localStorage.getItem("token") ?? "";
    this.sessionId = localStorage.getItem("sessionId") ?? "";
    this.structure = {
      OperatorID: this.operatorID,
      Data: "",
      TimeStamp: "",
      Seq: "0000",
      Sig: "",
    };
  }

  public getSessionId(): string {
    return this.sessionId;
  }
  public updateSessionId(id: string) {
    this.sessionId = id;
  }

  public getAccessToken(): string {
    return this.accessToken;
  }
  public updateAccessToken(tk: string) {
    this.accessToken = tk;
  }

  public getTokenInterface() {
    this.webAddress = this.webAddressPrefix + "app/query_token";
    let data =
      '{"OperatorID":"' +
      this.structure.OperatorID +
      '","OperatorSecret":"' +
      this.privateKey +
      '"}';
    this.prepareTheCallToShuncomAPI(data);
    new Promise(() => {
      this.serverPostRequest("getToken").then(
        (data: any) => {
          this.accessToken = data[2].split(":")[1].split('"')[1];
          localStorage.setItem("token", this.accessToken);
          console.log("Token guardado: ", this.accessToken);
        },
        (error) => {
          console.log(error.Msg);
          console.log("Error en la llamada de getToken: ", error);
        }
      );
    });

    return this.accessToken;
  }

  public shuncomLogin(username: string, password: string) {
    this.webAddress = this.webAddressPrefix + "app/user/v1_0/user_login";
    let data = '{"UserName":"' + username + '","Password":"' + password + '"}';
    this.prepareTheCallToShuncomAPI(data);
    return new Promise((resolve, reject) => {
      this.serverPostRequest("login").then(
        (data: any) => {
          let found = false;
          for (let i = 0; i < data.length; i++) {
            if (data[i].includes("SessionId")) {
              this.sessionId = data[i].split(":")[1].split('"')[1];
              localStorage.setItem("sessionId", this.sessionId);
              found = true;
              i = data.length;
            }
          }
          resolve(this.sessionId);
        },
        (error) => {
          reject(error);
        }
      );
    });
  }

  public equipmentStatusStatistics() {
    this.webAddress =
      this.webAddressPrefix + "app/commons/v1_0/device_status_statistics";
    let data = "";
    this.prepareTheCallToShuncomAPI(data);
    return new Promise((resolve, reject) => {
      this.serverPostRequest("equipmentStatusStatistics").then(
        (data: any) => {
          const newData = JSON.parse(data);
          resolve(newData);
        },
        (error) => {
          reject(error);
        }
      );
    });
  }

  public gatewaySearch(tipo: number, gwName: string) {
    //1 - Gateway normal. 100 - Gateway solar
    let platform = 1;
    let type = 1;
    //    let platform = 2;
    //    let type = 100;
    let skip = 0;
    let limit = 2000;
    let name = gwName;
    this.webAddress = this.webAddressPrefix + "app/commons/v1_0/read";
    let data = JSON.stringify({
      platform: platform,
      type: type,
      skip: skip,
      limit: limit,
      name: name,
    });
    this.prepareTheCallToShuncomAPI(data);

    return this.serverPostRequest("gatewaySearch");
  }

  public luminaireSearch(searchName: string) {
    let platform = 1;
    let type = 4; //This code makes reference to the luminaires (node type).
    let skip = 0;
    let limit = 20000;
    let name = searchName;
    this.webAddress = this.webAddressPrefix + "app/commons/v1_0/read";

    let data = JSON.stringify({
      platform: platform,
      type: type,
      skip: skip,
      limit: limit,
      name: name,
    });

    this.prepareTheCallToShuncomAPI(data);

    return this.serverPostRequest("luminaireSearch");
  }

  public createGateway(
    shuncomDiv: string,
    shuncomOrg: string,
    shuncomPrj: string
  ) {
    let platform = 1; //Platform type 1 or 2
    let type = 1; //Type for gateway
    let address = "0x12345677"; //Device address
    let controllerType = 3; //Type for gateway
    let formula = "1"; //I continue without knowing anything about this
    let encryption = 0; //Specify if we want encryption or not
    let division = shuncomDiv;
    let organization = shuncomOrg;
    let project = shuncomPrj;
    let latitude = "41.580696";
    let longitude = "2.229445";
    let registryPackage = ""; //You can get the value in a stick of the gateway with the name "Registration packet"
    let boxCode = registryPackage; //This value is the same as registryPackage
    let sectionCount = 4;
    let pollInterval = 5; //In minutes. Frequency to send information to the DB
    let name = "Javi1 Gateway";
    this.webAddress = this.webAddressPrefix + "app/commons/v1_1/create"; //v1_1 is used to add or delete devices

    let info = {
      platform: platform,
      type: type,
      addr: address, // Use lowercase
      property: {
        type: controllerType,
        name: name,
        longitude: latitude,
        latitude: longitude,
        formula: formula,
        encryption: encryption,
        division_id: division,
        organization_id: organization,
        project_id: project,
        box_code: boxCode,
        section_count: sectionCount,
        register_pkg: registryPackage,
        poll_interval: pollInterval,
      },
    };
  }

  public createNodeController(
    shuncomDiv: string,
    shuncomOrg: string,
    shuncomPrj: string
  ) {
    let platform = 1; //Platform type 1 or 2
    let type = 3; //Type for adding a light controller
    let address = "0x12345677"; //Device address
    let controllerType = 256; //Zigbee v3 - 23 | Solar Light controller - 256
    let gatewayId = "60e587a5181e9f0aae9f23f4";
    let section = 1;
    let division = shuncomDiv;
    let organization = shuncomOrg;
    let project = shuncomPrj;
    let lampPostType = 3; // 3 - Lamp post || 20 - Intelligent lamp post
    let name = "Javi1";
    this.webAddress = this.webAddressPrefix + "app/commons/v1_1/create"; //v1_1 is used to add or delete devices

    let info = {
      platform: platform,
      type: type, // type added is light controller
      addr: address, // light controller address
      property: {
        type: controllerType, //according to the actual light controller，type value see the list
        gateway_id: gatewayId, // Fill in according to the inquiry
        section_id: section, //loop number, crec que es el duankou
        division_id: division, //division
        organization_id: organization, //organization
        project_id: project, //Project
        lamp_post_type: lampPostType, //Pole type
        lamp_post_number: name,
      },
    };

    let data = JSON.stringify(info);
    this.prepareTheCallToShuncomAPI(data);
    return new Promise((resolve, reject) => {
      this.serverPostRequest("nodeCreation").then(
        (data: any) => {
          let devolucion =
            JSON.parse(data[0]).uid === undefined
              ? ""
              : JSON.parse(data[0]).uid;
          console.log(data);
          resolve(devolucion);
        },
        (error) => {
          console.log("Algo pasa. Error en la creación del controlador");
          reject(error);
        }
      );
    });
  }

  public createNodeLuminaire(
    shuncomDiv: string,
    shuncomOrg: string,
    shuncomPrj: string,
    uid: string
  ) {
    let platform = 1; //Platform type 1 or 2
    let type = 4; //Type value for adding a luminaire
    let address = "0x12345677"; //Device address. The same that in part 1
    let controllerType = 5; //Grid luminaire¿?
    let encryption = 0; // 0 - Non encrypted | 1 - Encrypted
    let pollInterval = 60;
    let formula = 1;
    let division = shuncomDiv;
    let organization = shuncomOrg;
    let project = shuncomPrj;
    let latitude = "41.580696";
    let longitude = "2.229445";
    let port = 1;
    let name = "JaviTest2";
    this.webAddress = this.webAddressPrefix + "app/commons/v1_1/create"; //v1_1 is used to add or delete devices

    const data = JSON.stringify({
      platform: platform,
      type: type,
      addr: address,
      property: {
        type: controllerType,
        encryption: encryption,
        poll_interval: pollInterval,
        formula: formula,
        division_id: division,
        organization_id: organization,
        project_id: project,
        latitude: latitude,
        longitude: longitude,
        lamp_ctrl_id: uid,
        port_id: port,
        name: name,
      },
    });
    console.log("El JSON de la segunda parte: ", data);

    this.prepareTheCallToShuncomAPI(data);
    return new Promise((resolve, reject) => {
      this.serverPostRequest("nodeCreation2").then(
        (data: any) => {
          console.log("Respuesta de la segunda parte: ", data);
          resolve(data);
        },
        (error) => {
          console.log("Error en la creación de la luminaria");
          reject(error);
        }
      );
    });
  }

  public deleteNode(uid: string, lampControlId: string) {
    let platform = 1; //Platform type 1 or 2
    let type = 4; //Type for adding a light controller
    let controllerType = 23; //Zigbee v3 - 23 | Solar Light controller - 256
    this.webAddress = this.webAddressPrefix + "app/commons/v1_1/delete"; //v1_1 is used to add or delete devices

    //We need to delete it in two phases:
    const data = JSON.stringify({
      platform: platform,
      type: type,
      uid: uid,
      property: {
        type: controllerType,
      },
    });

    this.prepareTheCallToShuncomAPI(data);
    return new Promise((resolve, reject) => {
      this.serverPostRequest("nodeCreation").then(
        (data: any) => {
          //If everything is ok, then we need to execute the second phase:
          type = 3;
          let info = {
            platform: platform,
            type: type,
            uid: lampControlId,
            property: {
              type: controllerType,
            },
          };

          let data2 = JSON.stringify(info);
          this.prepareTheCallToShuncomAPI(data2);
          return new Promise((resolve, reject) => {
            this.serverPostRequest("nodeCreation").then(
              (data: any) => {
                //If everything is ok, then we need to execute the second phase:
                console.log(data);
                resolve(data);
              },
              (error) => {
                console.log("Error con el borrado 2 del nodo");
                reject(error);
              }
            );
          });
        },
        (error) => {
          console.log("Error con el borrado del nodo");
          reject(error);
        }
      );
    });
  }

  public luminaireControl(arrayOfOrders: any[]) {
    let arrayOfStandardLuminaires: any[] = [];
    let arrayOfSolarLuminaires: any[] = [];

    arrayOfOrders.forEach((order) => {
      if (order.type === 23) arrayOfStandardLuminaires.push(order);
      else if (order.type === 256) arrayOfSolarLuminaires.push(order);
    });

    let data = "";
    if (arrayOfStandardLuminaires.length > 0) {
      data = this.controlStandardLuminaires(arrayOfStandardLuminaires);
      this.prepareTheCallToShuncomAPI(data);
      return new Promise((resolve, reject) => {
        this.serverPostRequest("luminaireControl").then(
          (data: any) => {
            let lum = JSON.parse(data);
            resolve(lum);
          },
          (error) => {
            reject(error);
          }
        );
      });
    }
    console.log("Datos mezclados: ", data);
    if (arrayOfSolarLuminaires.length > 0) {
      data = this.controlSolarLuminaires(arrayOfSolarLuminaires);
      this.prepareTheCallToShuncomAPI(data);
      return new Promise((resolve, reject) => {
        this.serverPostRequest("luminaireControl").then(
          (data: any) => {
            let lum = JSON.parse(data);
            resolve(lum);
          },
          (error) => {
            reject(error);
          }
        );
      });
    }
    return 0;
  }

  public controlStandardLuminaires(arrayOfOrders: any[]): string {
    let platform = 1;
    const code = 1; //Es el código de la orden a ejecutar
    let headSerial = 1; //Número incremental con cada llamada
    this.webAddress = this.webAddressPrefix + "app/commons/v1_0/send";

    //We need to construct the info to send
    let data = JSON.stringify({
      platform: platform,
      cmds: arrayOfOrders.map((order) => ({
        addr: order.address,
        code: code,
        gatewayAddr: order.gwAddress,
        headSerial: headSerial++,
        uid: order.lampId,
        control: {
          devtype: order.type,
          [order.order == 2 ? "bri" : "on"]: order.dimming || order.order,
        },
      })),
    });
    return data;
  }

  public controlSolarLuminaires(arrayOfOrders: any[]): string {
    console.log("Control luminaria solar");
    const platform = 2;
    //    const code = 101; // Este código indica Solar Parameter Settings
    const code = 101; // Este código indica el on/off de la lámpara
    const ep = 1; // Tampoco sé su uso
    let headSerial = 1; // Número incremental con cada llamada

    const thdwktim = 6;
    const fthwkp = 20;
    const scdwktim = 2;
    const thdwkp = 20;
    const scdwkp = 40;
    const ledcurr = "0.33";
    const fstwktim = 4;
    const fthwktim = 3;
    const ltctrldltim = 1;
    const fstwkp = 70;
    const ensmtctrlp = 0;
    const argcgtim = 1;
    const batcgmaxtemp = 24;
    const ltctrlvolt = "5.0";
    const oodrcvvolt = "12.6";
    const risercvcgvolt = "13.2";
    const argcgitv = 30;
    const battype = 0;
    const pwswchvolt = "11.5";
    const voltMax = "17";
    const almvoltLow = "12";
    const argcgvolt = "14.8";
    const oodvolt = "11";
    const tempco = 3;
    const risecgtim = 4;
    const batcgmintemp = 6;
    const batodmintemp = 6;
    const risecgvolt = "14.4";
    const fltcgvolt = "13.8";
    const lmtcgvolt = "15.5";
    const sysvolt = 12;
    const batodmaxtemp = 24;

    this.webAddress = this.webAddressPrefix + "app/commons/v1_0/send";

    // We need to construct the info to send
    let data = '{"platform":' + platform + "," + '"cmds":[{';

    //console.log("Luminaria a controlar: ", arrayOfOrders);

    console.log(arrayOfOrders);
    for (let i = 0; i < arrayOfOrders.length; i++) {
      //Data for dimming
      data +=
        '"addr":"' +
        arrayOfOrders[i].address +
        '",' +
        '"id":"' +
        arrayOfOrders[i].address +
        '",' +
        '"code":' +
        code +
        "," +
        '"gatewayAddr":"' +
        arrayOfOrders[i].gwAddress +
        '",' +
        '"headSerial":' +
        headSerial +
        "," +
        '"ep":' +
        ep +
        "," +
        '"uid":"' +
        arrayOfOrders[i].lampId +
        '",' +
        '"control":{' +
        '"devtype":' +
        arrayOfOrders[i].type +
        "," +
        '"on":' +
        arrayOfOrders[i].order /*',' +
          '"thdwktim":' + thdwktim + ',' +
          '"fthwkp":' + fthwkp + ',' +
          '"scdwktim":' + scdwktim + ',' +
          '"thdwkp":' + thdwkp + ',' +
          '"scdwkp":' + scdwkp + ',' +
          '"ledcurr":"' + ledcurr + '",' +
          '"fstwktim":' + fstwktim + ',' +
          '"fthwktim":' + fthwktim + ',' +
          '"ltctrldltim":' + ltctrldltim + ',' +
          '"fstwkp":' + fstwkp + ',' +
          '"ensmtctrlp":' + ensmtctrlp + ',' +
          '"argcgtim":' + argcgtim + ',' +
          '"batcgmaxtemp":' + batcgmaxtemp + ',' +
          '"ltctrlvolt":"' + ltctrlvolt + '",' +
          '"oodrcvvolt":"' + oodrcvvolt + '",' +
          '"risercvcgvolt":"' + risercvcgvolt + '",' +
          '"argcgitv":' + argcgitv + ',' +
          '"battype":' + battype + ',' +
          '"pwswchvolt":"' + pwswchvolt + '",' +
          '"voltMax":"' + voltMax + '",' +
          '"almvoltLow":"' + almvoltLow + '",' +
          '"argcgvolt":"' + argcgvolt + '",' +
          '"oodvolt":"' + oodvolt + '",' +
          '"tempco":' + tempco + ',' +
          '"risecgtim":' + risecgtim + ',' +
          '"batcgmintemp":' + batcgmintemp + ',' +
          '"batodmintemp":' + batodmintemp + ',' +
          '"risecgvolt":"' + risecgvolt + '",' +
          '"fltcgvolt":"' + fltcgvolt + '",' +
          '"lmtcgvolt":"' + lmtcgvolt + '",' +
          '"sysvolt":' + sysvolt + ',' +
          '"batodmaxtemp":' + batodmaxtemp + */ +
        "}}";
      if (i + 1 < arrayOfOrders.length) data += ",{";
      else data += "]}";
      headSerial++;
    }

    return data;
  }

  private prepareTheCallToShuncomAPI(data: string) {
    this.structure.Data = this.servicioEncriptacion.encryptMessage(
      this.structure.OperatorID,
      data
    );

    //Now we fill the common fields
    this.fillCommonFields();

    //Finally, we get the signature field
    const signatureMessage =
      this.structure.OperatorID +
      this.structure.Data +
      this.structure.TimeStamp +
      this.structure.Seq;
    const hash = this.servicioEncriptacion.calculateMD5(signatureMessage);
    this.structure.Sig = hash.toUpperCase();
  }

  private fillCommonFields() {
    //timeStamp field
    let date = new Date();
    let dateString =
      date.getFullYear().toString() +
      (date.getMonth() + 1).toString().padStart(2, "0") +
      date.getDate().toString().padStart(2, "0") +
      (date.getHours() + 1).toString().padStart(2, "0") + //We add 1 because of the UTC problem format with Shuncom
      date.getMinutes().toString().padStart(2, "0") +
      date.getSeconds().toString().padStart(2, "0");

    this.structure.TimeStamp = dateString;

    //seq field
    this.sequence = +this.structure.Seq;
    this.sequence += 1;
    this.structure.Seq = this.sequence.toString().padStart(4, "0");
  }

  // This is the server to send Post Requests

  private async serverPostRequest(order: string) {
    let header = {
      OperatorID: this.operatorID,
      Data: "",
      TimeStamp: "",
      Seq: "0000",
      Sig: "",
      "Content-Type": "application/json",
      Authorization: `Bearer ${this.getAccessToken()}`,
      // Check the order and add the SessionId header
      SessionId: order !== "getToken" || "login" ? this.sessionId : "",
    };

    // Use the async/await syntax to simplify the code and avoid using a Promise
    try {
      // Send the HTTP request and wait for the response
      //const data = await this.http.post<any>(this.webAddress, this.structure, requestOptions).toPromise();

      const response = await fetch(this.webAddress, {
        method: "POST",
        headers: header,
        body: JSON.stringify(this.structure),
      });

      const data = await response.json();

      //Check the response status
      if (data.Ret !== 0) {
        // Reject the Promise with the error message

        throw new Error(data.message);
      }

      // Decrypt the response data

      const receivedInfoArray = this.servicioEncriptacion.decryptMessage(
        data.Data,
        order
      );

      console.log("info recibida", JSON.parse(receivedInfoArray));

      // Return the decrypted data
      return receivedInfoArray;
    } catch (error: unknown) {
      // Reject the Promise with the error
      console.error(error);
    }
  }

  private async sendCommandToSmartec() {
    const request = new XMLHttpRequest();
    request.open("GET", "http://159.223.30.89:3000/products/1767199611/off");
    request.onreadystatechange = function () {
      if (this.readyState === 4 && this.status === 200) {
        console.log("Respuesta: " + this.responseText);
      }
    };
    request.send();
  }

  public async switchOnLuminaires(luminaires: Array<Lamp>, order: number) {
    try {
      const data = this.prepareLuminaireOrder(
        luminaires.filter((luminaire) => luminaire.online),
        order
      );
      this.prepareTheCallToShuncomAPI(data);

      const response: string[] = await this.serverPostRequest(
        "luminaireControl"
      );

      return response;
    } catch (error: unknown) {
      console.error((error as Error).message);
      return 0;
    }
  }

  private prepareLuminaireOrder(
    luminaires: Array<Lamp>,
    order: number,
    dimming?: number
  ): string {
    let platform = 1;
    const code = 1; //Es el código de la orden a ejecutar
    let headSerial = 1; //Número incremental con cada llamada
    this.webAddress = this.webAddressPrefix + "app/commons/v1_0/send";

    const dimmingControl = {
      devtype: 23,
      bri: dimming,
    };

    const onOffControl = {
      devtype: 23,
      on: order,
    };
    //We need to construct the info to send
    let data = JSON.stringify({
      platform: platform,
      cmds: luminaires.map((lamp) => ({
        addr: lamp.addr,
        code: code,
        gatewayAddr: lamp.gateway_addr,
        headSerial: headSerial++,
        uid: lamp.lamp_ctrl_id,
        control: dimming ? dimmingControl : onOffControl,
      })),
    });

    console.log("JSON a enviar", JSON.parse(data));

    return data;
  }

  public async dimmingStandardLuminaires(
    luminaires: Array<NodeDevice>,
    dimming: number
  ) {
    try {
      const data = this.prepareLuminaireOrder(
        luminaires.filter((luminaire) => luminaire.online),
        2,
        dimming
      );
      this.prepareTheCallToShuncomAPI(data);

      const response: string[] = await this.serverPostRequest(
        "luminaireControl"
      );

      return response[2].includes("9013") ? 1 : 0;
    } catch (error: unknown) {
      console.error((error as Error).message);
      return 0;
    }
  }
}
