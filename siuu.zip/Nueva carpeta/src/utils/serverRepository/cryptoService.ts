import * as CryptoJS from "crypto-js";
export class CryptoService {
  private privateKey: string = "1234567890abcdef";
  private ivKey: string = "1234567890abcdef";

  public calculateMD5(message: string): string {
    let hash = CryptoJS.HmacMD5(message, this.privateKey);
    return hash.toString();
  }

  public encryptMessage(user: string, message: string): string {
    let key128Bits = CryptoJS.enc.Utf8.parse(this.privateKey);
    let iv = CryptoJS.enc.Utf8.parse(this.ivKey);
    let encrypted = CryptoJS.AES.encrypt(message, key128Bits, {
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
      iv: iv,
    });
    return encrypted.toString();
  }

  public decryptMessage(message: string, order: string): any {
    let key128Bits = CryptoJS.enc.Utf8.parse(this.privateKey);
    let iv = CryptoJS.enc.Utf8.parse(this.ivKey);
    let desencriptado = CryptoJS.AES.decrypt(message, key128Bits, {
      iv: iv,
    });

    let infoArray;
    if (order === "luminaireSearch")
      infoArray = desencriptado.toString(CryptoJS.enc.Utf8);
    //desecnripta el mensaje y transforma a un json
    else infoArray = desencriptado.toString(CryptoJS.enc.Utf8).split(",");
    return infoArray;
  }
}
