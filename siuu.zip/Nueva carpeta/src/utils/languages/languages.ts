export const languages = {
  english: {
    cardInfo: {
      "Total luminaires": "Total luminaires",
      "ON luminaires": "ON luminaires",
      "Connected luminaires": "Connected luminaires",
      Alarms: "Alarms",
      Consumption: "Consumption",
      "Not positioned": "Not positioned",
    },

    filters: {
      Connected: "Connected",
      Disconnected: "Disconnected",
      Alarms: "Alarms",
      ON: "ON",
      OFF: "OFF",
    },

    detailsPopup: {
      Connected: "Connected",
      Disconnected: "Disconnected",
      ON: "ON",
      OFF: "OFF",
      Status: "Status",
      "View details": "View details",
      "Devices selected": "Devices selected",
      Alarms: "Alarms",
      "Bulk actions": "Bulk actions",
      luminaires: "luminaires",
      gateways: "gateways",
      Connection: "Connection",
    },
  },

  catala: {
    cardInfo: {
      "Total luminaires": "Totes les lluminàries",
      "ON luminaires": "Lluminàries enceses",
      "Connected luminaires": "Lluminàries conectades",
      Alarms: "Alarmes",
      Consumption: "Consum",
    },
    filters: {
      Connected: "Conectat",
      Disconnected: "Desconectat",
      Alarms: "Alarmes",
      ON: "ON",
      OFF: "OFF",
    },
  },
};

export type Language = "english";

//una vez añadidas las traducciones es ir añadiendo al type Language el lenguaje añadido, y usar el hook useLanguage que lo que hará es setear el nuevo idioma. Por defecto inglés.

/*un ejemplo de uso seriá:
 <button onClick={()=>useLanguage("english")}>English</button>
 
 */
