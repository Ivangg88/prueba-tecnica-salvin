import {
  featureGroup,
  Icon,
  LatLng,
  layerGroup,
  Map,
  marker,
  polygon,
} from "leaflet";
import { resolve } from "path";
import { lampActionsStruct } from "../../app/models/lamp-actions-struct";
import { lampDataStruct } from "../../app/models/lamp-data-struct";
import { Lamp } from "../../types/interfaces";
import { serverCallings } from "../serverRepository/serverCallings";

export class CallRepository {
  private servidorLlamadas: any;
  public arrayOfOrganizations: any = [];
  public organizationSelected: any;
  private arrayOfProjects: any = [];
  public projectsOfTheCurrentOrganization: any = [];
  public projectSelected: any;
  public nodesOfTheCurrentProject: any = [];
  public nodesClickedOnTheMap: any[] = [];
  public filteredNodesOfTheCurrentProject: any[] = [];
  private arrayOfGateways: any = [];
  private arrayOfNodes: Lamp[] = [];
  public dropdownGateway: string[];
  public selectedGateway: string;
  public dataLoaded = false;
  public dimmingValue = 50;
  public selectedLampInfo: lampDataStruct;
  public infoLampVisible = "visible"; //'hidden';
  private markersMap: any = [];
  private drawingArea = 0;
  public myPolygonSelection: any;
  public polygonCoordinates: LatLng[] = [];
  private timeoutId: any;
  private myMap: any;
  private onIcon = new Icon({
    iconUrl:
      "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-gold.png",
    shadowUrl:
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
  });
  private disconnectedIcon = new Icon({
    iconUrl:
      "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png", //https://pic.onlinewebfonts.com/svg/img_381656.png',
    shadowUrl: "",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
  });
  private offIcon = new Icon({
    iconUrl:
      "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-grey.png",
    shadowUrl: "",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
  });

  constructor(sender: serverCallings) {
    this.dropdownGateway = [];
    this.selectedGateway = "";
    this.selectedLampInfo = { lampName: "" };
    let accessToken = "";
    let sessionId = "";

    this.servidorLlamadas = sender;
  }

  getStatus() {
    //This is done and working, but we don't use it. It's useless

    this.servidorLlamadas.sendCommandToSmartec();
    /*
    this.servidorLlamadas.equipmentStatusStatistics().then(
      (data: any) => {
        if (data.length > 0) {
          console.log('Datos de status: ', data);
        }
        else {
          console.log('No recibo ninguna estadística instalación');
        }
      },
      (error: any) => {
        console.log('Error: ', error);
      }
    );*/
  }

  // getGateways(tipo: number, gwName: string) {
  //   this.servidorLlamadas.gatewaySearch().then(
  //     (data: any) => {
  //       if (data.total > 0) {
  //         data.rows.forEach((row: any) => {
  //           this.arrayOfGateways.push(row);
  //           this.dropdownGateway.push(row.name);
  //         });
  //       } else {
  //         console.log("No hay ningún Gateway");
  //       }
  //     },
  //     (error: any) => {
  //       console.log("Error: ", error);
  //     }
  //   );
  // }

  // getNodes(name: string) {
  //   this.servidorLlamadas.luminaireSearch(name).then(
  //     (data: any) => {
  //       if (data.total > 0) {
  //         data.rows.forEach((row: any) => {
  //           this.arrayOfNodes.push(row);
  //         });
  //         //Aquí están todas las lamp poles que tengo en mi proyecto
  //         //          console.log("Este es el primer nodo encontrado: ", this.arrayOfNodes[0]);
  //         this.getOrganizationsAndProjects();
  //         this.dataLoaded = true;

  //         if (this.arrayOfOrganizations.length === 1) {
  //           this.organizationSelected = this.arrayOfOrganizations[0];
  //           this.filterProjects();
  //         }
  //       } else {
  //         console.log("No he encontrado ningún nodo");
  //       }
  //     },
  //     (error: any) => {
  //       console.log("Error: ", error);
  //     }
  //   );
  // }

  // We are going to get the different projects from the project name inside the gateways.
  // This is the only way we have at this moment to do it
  getOrganizationsAndProjects() {
    let auxiliarArray: { orgName: String; orgId: String }[] = [];
    this.arrayOfOrganizations.length = 0;
    this.arrayOfNodes.forEach((node: any) => {
      if (
        auxiliarArray.find((obj) => obj.orgName === node.orgName) === undefined
      ) {
        auxiliarArray.push({
          orgName: node.orgName,
          orgId: node.organizationId,
        });
      }
      if (!this.arrayOfProjects.includes(node.prjName)) {
        this.arrayOfProjects.push(node);
      }
    });
    this.arrayOfOrganizations = auxiliarArray;
  }

  filterProjects() {
    let auxiliarArray: { prjName: String; prjId: String }[] = [];
    let organizationSearched = this.organizationSelected.orgId;

    this.arrayOfProjects.forEach((project: any) => {
      if (project.organizationId === organizationSearched) {
        if (
          auxiliarArray.find((obj) => obj.prjName === project.prjName) ===
          undefined
        ) {
          auxiliarArray.push({
            prjName: project.prjName,
            prjId: project.projectId,
          });
        }
      }
    });

    this.projectsOfTheCurrentOrganization = auxiliarArray;

    if (this.projectsOfTheCurrentOrganization.length === 1) {
      this.projectSelected = this.projectsOfTheCurrentOrganization[0];
      this.filterNodes();
    }
  }

  // This function filters the nodes
  filterNodes() {
    // Create an auxiliary array to store the nodes that match the filter
    let auxiliarArray: { nodeName: String; nodeAdr: String }[] = [];
    // Get the ID of the selected project
    let projectSearched = this.projectSelected.prjId;

    // Iterate over the array of nodes
    this.arrayOfNodes.forEach((node: any) => {
      // If the node belongs to the selected project, add it to the auxiliary array
      if (node.projectId === projectSearched) {
        auxiliarArray.push(node);
        // If the node has latitude and longitude coordinates, add them to the map
        if (
          node.latitude != "" &&
          node.longitude != "" &&
          node.latitude != undefined &&
          node.longitude != undefined
        ) {
          // Add the node coordinates to the map
        }
      }
    });
    // Update the filteredNodesOfTheCurrentProject array with the filtered nodes
    this.filteredNodesOfTheCurrentProject = auxiliarArray;
    // Update the nodesClickedOnTheMap array with the filtered nodes
    this.nodesClickedOnTheMap = auxiliarArray;
    // Update the nodesOfTheCurrentProject array with the filtered nodes
    this.nodesOfTheCurrentProject = auxiliarArray;
    // Show all the nodes of the current project on the map
    // this.showAllProjectNodes();
  }

  turnOnOffVisualizedLampsInMap(order: Number) {
    let arrayOfOrders: any[] = [];
    for (let i = 0; i < this.nodesClickedOnTheMap.length; i++) {
      //To send the order, we want that the luminaires were online and in a different state (on != off || off != on)
      //      if (this.nodesClickedOnTheMap[i].online === 1 && this.nodesClickedOnTheMap[i].on != order) {
      arrayOfOrders.push({
        address: this.nodesClickedOnTheMap[i].addr,
        order: order,
        dimming: this.dimmingValue,
        lampId: this.nodesClickedOnTheMap[i].lamp_ctrl_id,
        gwAddress: this.nodesClickedOnTheMap[i].gateway_addr,
        type: this.nodesClickedOnTheMap[i].lamp_ctrl_type,
      });
      //      }
      //      else
      //        console.log("Luminaria sin acceso.");
    }
    if (arrayOfOrders.length === 0) console.log("Nada que controlar");
    else {
      this.servidorLlamadas.luminaireControl(arrayOfOrders).then(
        (data: any) => {
          for (let i = 0; i < data.length; i++) {
            console.log("Resultado de la llamada: ", data[i]);
            if (data[i].result === 0) {
              //If result = 0 we need to change the state of the marker.
              for (let j = 0; j < this.nodesClickedOnTheMap.length; j++) {
                if (
                  this.nodesClickedOnTheMap[j].lamp_ctrl_id ===
                  arrayOfOrders[data[i].headSerial - 1].lampId
                ) {
                  if (order != 2) this.nodesClickedOnTheMap[j].on = order;
                  else this.nodesClickedOnTheMap[j].bri = this.dimmingValue;
                  j = this.nodesClickedOnTheMap[j].length;
                }
              }
              //this.showPositionInMap();
            }
          }
          console.log("La respuesta a las órdenes: ", data);
        },
        (error: any) => {
          console.log("Error: ", error);
        }
      );
    }
  }

  // showAllProjectNodes() {
  //   this.filteredNodesOfTheCurrentProject = this.nodesOfTheCurrentProject;
  //   this.showPositionInMap();
  // }

  async createANewNode() {
    let myUID;
    // Check if an organization, project, and node are selected
    if (this.organizationSelected.orgId === undefined) {
      // If not, log a message and return
      console.log("There is no organization created.");
      return;
    }
    if (this.projectSelected.prjId === undefined) {
      // If not, log a message and return
      console.log("There is no project created.");
      return;
    }
    if (this.filteredNodesOfTheCurrentProject.length < 0) {
      // If not, log a message and return
      console.log("There is no node created.");
      return;
    }
    // Log the selected node
    console.log(this.filteredNodesOfTheCurrentProject[0]);

    try {
      // Send the createNodeController request and wait for the response
      myUID = await this.servidorLlamadas.createNodeController(
        this.filteredNodesOfTheCurrentProject[0].divisionId,
        this.organizationSelected.orgId,
        this.projectSelected.prjId
      );
      // If there is an error, log a message
      if (myUID === "") {
        console.log("Hay un error en la creación del driver");
        return;
      }
      // Otherwise, create the second part of the node
      // Send the createNodeLuminaire request and wait for the response
      const data2 = await this.servidorLlamadas.createNodeLuminaire(
        this.filteredNodesOfTheCurrentProject[0].divisionId,
        this.organizationSelected.orgId,
        this.projectSelected.prjId,
        myUID
      );
      // Log the response
      console.log("La respuesta a las órdenes de la segunda parte: ", data2);
    } catch (error) {
      // Log the error
      this.deleteNode(myUID, "");
      console.log("Error: ", error);
    }
  }

  deleteNode(uid: string, lampControlId: string) {
    this.servidorLlamadas.deleteNode(uid, lampControlId).then(
      (data: any) => {
        console.log("¿Lo habremos podido borrar?", data);
      },
      (error: any) => {
        console.log("Error: ", error);
      }
    );
  }

  // The next 2 functions works for a detect a long press in "delete node to be sure that we want to delete it"
  // Function that is called when the user presses the button
  handleMouseDown() {
    // Stores the current time in a variable
    console.log("Douse Monw");
    let startTime = Date.now();

    // Sets a timeout to check if the user has held the button for more than 3 second
    this.timeoutId = setTimeout(() => {
      // Calculates the elapsed time
      let elapsedTime = Date.now() - startTime;

      // If the elapsed time is greater than 5 second, executes the desired action
      if (elapsedTime >= 5000) {
        // Your code to execute the desired action goes here
        for (let i = 0; i < this.filteredNodesOfTheCurrentProject.length; i++) {
          let theUID = this.filteredNodesOfTheCurrentProject[i].uid;
          let theLampCtrlId =
            this.filteredNodesOfTheCurrentProject[i].lamp_ctrl_id;
          // -------------------- DESCOMENTAR FUNCIÓN CUANDO QUERAMOS BORRAR NODOS ------------------------------          this.deleteNode(theUID, theLampCtrlId);
        }
      }
    }, 5000);
  }

  // Function that is called when the user releases the button
  handleMouseUp() {
    console.log("Uouse Mp");
    // Clears the timeout to stop checking the elapsed time
    clearTimeout(this.timeoutId);
  }

  showPositionInMap() {
    this.myMap.markers = {};
    var markerArray = [];
    let markerIcon;

    for (let i = 0; i < this.filteredNodesOfTheCurrentProject.length; i++) {
      if (
        this.filteredNodesOfTheCurrentProject[i].latitude != "" &&
        this.filteredNodesOfTheCurrentProject[i].longitude != "" &&
        this.filteredNodesOfTheCurrentProject[i].latitude != undefined &&
        this.filteredNodesOfTheCurrentProject[i].longitude != undefined
      ) {
        if (+this.filteredNodesOfTheCurrentProject[i].online === 0) {
          markerIcon = this.disconnectedIcon;
        } else {
          if (+this.filteredNodesOfTheCurrentProject[i].on === 1)
            markerIcon = this.onIcon;
          else markerIcon = this.offIcon;
        }
        const newMarker = marker(
          [
            this.filteredNodesOfTheCurrentProject[i].latitude,
            this.filteredNodesOfTheCurrentProject[i].longitude,
          ],
          {
            icon: this.onIcon,
            title: this.filteredNodesOfTheCurrentProject[i].name,
            riseOnHover: true,
          }
        );
        newMarker.on("click", (e) => {
          this.mouseActions("click", e.sourceTarget.options.title);
        });
        newMarker.on("dblclick", () => {
          this.myMap.removeLayer(newMarker);
          this.mouseActions("double_click", "");
        });
        markerArray.push(newMarker);
      } else {
        console.log(
          "La luminaria seleccionada no tiene posición marcada!. Seleccionar posición"
        );
        console.log(this.filteredNodesOfTheCurrentProject[i]);
      }
    }
    if (this.markersMap != undefined) this.myMap.removeLayer(this.markersMap);
    if (markerArray.length > 0) {
      this.markersMap = layerGroup(markerArray);
      this.myMap.flyToBounds(featureGroup(markerArray).getBounds(), {
        animate: 0.1,
        easeLinearity: 0.01,
        padding: [5, 5],
      });
      // Delete the area drawn
      if (this.myPolygonSelection != undefined)
        this.myMap.removeLayer(this.myPolygonSelection);
    }
  }

  private mouseActions(action: string, lampName: string): void {
    this.nodesClickedOnTheMap = [];
    if (action === "click") {
      for (let i = 0; i < this.filteredNodesOfTheCurrentProject.length; i++) {
        if (this.filteredNodesOfTheCurrentProject[i].name === lampName)
          console.log("Los nodos: ", this.filteredNodesOfTheCurrentProject[i]);
        this.nodesClickedOnTheMap.push(
          this.filteredNodesOfTheCurrentProject[i]
        );
      }
      this.selectedLampInfo.lampName = lampName;
      this.infoLampVisible = "visible";
    }
    console.log("Han hecho ", action);
  }

  public executeChildOrder(actionToExecute: lampActionsStruct) {
    if (actionToExecute.off) this.turnOnOffVisualizedLampsInMap(0);
    else if (actionToExecute.on) this.turnOnOffVisualizedLampsInMap(1);
    else {
      this.dimmingValue = actionToExecute.dim;
      this.turnOnOffVisualizedLampsInMap(2);
    }
  }

  public drawPolygon() {
    this.filteredNodesOfTheCurrentProject = this.arrayOfNodes;

    this.drawingArea = 0;
    if (this.myPolygonSelection != undefined) {
      this.myMap.removeLayer(this.myPolygonSelection);
      this.polygonCoordinates = [];
    }
    this.myMap.on("mousedown", (e: { latlng: LatLng }) => {
      if (this.drawingArea < 1) this.drawingArea++;
      else {
        this.myMap.off("mousedown");
        this.myMap.off("mousemove");
        // Aquí vamos a mirar las que hay dentro de la zona

        this.nodesClickedOnTheMap = [];

        for (let i = 0; i < this.filteredNodesOfTheCurrentProject.length; i++) {
          if (
            this.isMarkerInsidePolygon(this.filteredNodesOfTheCurrentProject[i])
          )
            this.nodesClickedOnTheMap.push(
              this.filteredNodesOfTheCurrentProject[i]
            );
        }
        if (this.nodesClickedOnTheMap.length > 0) {
          this.filteredNodesOfTheCurrentProject = this.nodesClickedOnTheMap;
        }

        this.showPositionInMap();
      }
    });

    this.myMap.on("mousemove", (e: { latlng: LatLng }) => {
      if (this.drawingArea === 1) {
        if (this.myPolygonSelection != undefined)
          this.myMap.removeLayer(this.myPolygonSelection);
        this.polygonCoordinates.push(e.latlng);
        this.myPolygonSelection = polygon(this.polygonCoordinates, {
          color: "darkblue",
          fill: true,
          fillColor: "blue",
          fillOpacity: 0.25,
          weight: 5,
        }).addTo(this.myMap);
      }
    });

    console.log("Seleccionadas", this.nodesClickedOnTheMap);

    return new Promise<Lamp[]>((resolve) => this.nodesClickedOnTheMap);
  }

  private isMarkerInsidePolygon(myNode: any) {
    const polyPoints = this.myPolygonSelection.getLatLngs()[0];
    let lngPositiveCross = 0;
    let lngNegativeCross = 0;
    let latPositiveCross = 0;
    let latNegativeCross = 0;

    if (myNode.latitude !== undefined && myNode.latitude !== "")
      //If my node doesn't have coordinates, we don't go inside
      for (let i = 1; i < polyPoints.length; i++) {
        //We explore all the polyPoints

        //First of all, the latitude
        if (
          (polyPoints[i - 1].lat - myNode.latitude) *
            (polyPoints[i].lat - myNode.latitude) <
            0 ||
          polyPoints[i].lat === myNode.latitude
        ) {
          //If we detect 2 consecutive points that cross the latitude of the markers...
          const mbLine = this.calculateM_B(
            polyPoints[i - 1].lat,
            polyPoints[i - 1].lng,
            polyPoints[i].lat,
            polyPoints[i].lng
          );
          if (
            this.calculatePositionRelativeToLine(
              mbLine,
              myNode.latitude,
              myNode.longitude
            ) === true
          )
            lngPositiveCross++;
          else lngNegativeCross++;
        }
        //Now is the turn for longitude
        if (
          (polyPoints[i - 1].lng - myNode.longitude) *
            (polyPoints[i].lng - myNode.longitude) <
            0 ||
          polyPoints[i].lng === myNode.longitude
        ) {
          //If we detect 2 consecutive points that cross the latitude of the markers...
          const mbLine = this.calculateM_B(
            polyPoints[i - 1].lng,
            polyPoints[i - 1].lat,
            polyPoints[i].lng,
            polyPoints[i].lat
          );
          if (
            this.calculatePositionRelativeToLine(
              mbLine,
              myNode.longitude,
              myNode.latitude
            ) === true
          )
            latPositiveCross++;
          else latNegativeCross++;
        }
      }

    //Now we need to study the last point and the first one to close the loop

    if (
      (polyPoints[polyPoints.length - 1].lat - myNode.latitude) *
        (polyPoints[0].lat - myNode.latitude) <
        0 ||
      polyPoints[0].lat == myNode.latitude
    ) {
      const mbLine = this.calculateM_B(
        polyPoints[polyPoints.length - 1].lat,
        polyPoints[polyPoints.length - 1].lng,
        polyPoints[0].lat,
        polyPoints[0].lng
      );
      if (
        this.calculatePositionRelativeToLine(
          mbLine,
          myNode.latitude,
          myNode.longitude
        ) == true
      )
        lngPositiveCross++;
      else lngNegativeCross++;
    }
    //Now is the turn for longitude
    if (
      (polyPoints[polyPoints.length - 1].lng - myNode.longitude) *
        (polyPoints[0].lng - myNode.longitude) <
        0 ||
      polyPoints[0].lng == myNode.longitude
    ) {
      //If we detect 2 consecutive points that cross the latitude of the markers...
      const mbLine = this.calculateM_B(
        polyPoints[polyPoints.length - 1].lng,
        polyPoints[polyPoints.length - 1].lat,
        polyPoints[0].lng,
        polyPoints[0].lat
      );
      if (
        this.calculatePositionRelativeToLine(
          mbLine,
          myNode.longitude,
          myNode.latitude
        ) == true
      )
        latPositiveCross++;
      else latNegativeCross++;
    }

    if (
      lngNegativeCross *
      lngPositiveCross *
      latNegativeCross *
      latPositiveCross
    )
      return true;
    return false;
  }

  calculatePositionRelativeToLine(mbLin: any, x: number, y: number) {
    //We return true if there is in one side of the line. false if it's in the other side
    if (mbLin.m * x + mbLin.b > y) return true;
    return false;
  }

  calculateM_B(x1: number, y1: number, x2: number, y2: number) {
    let mLine = 0;
    let bLine = 0;
    mLine = (y2 - y1) / (x2 - x1);
    bLine = y1 - mLine * x1;
    return { m: mLine, b: bLine };
  }

  public setNewMap(map: Map) {
    this.myMap = map;
  }

  public addNodes(nodes: Lamp[]) {
    this.arrayOfNodes = nodes;
    this.nodesOfTheCurrentProject = nodes;
  }

  public getSelectedNodes(): Lamp[] {
    return this.nodesClickedOnTheMap;
  }
}
