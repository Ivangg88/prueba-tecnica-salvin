import { LatLng } from "leaflet";
import { gateway, initialLamp } from "../utils/data";
import { Language } from "../utils/languages/languages";

export interface Userlogin {
  userName: string;
  password: string;
}

export interface UserLoged {
  userName: string;
  token: string;
  isLogged: boolean;
  timeStamp: string;
}

export interface Token {
  userName: string;
  timeStamp: string;
  isLogged: boolean;
}

export interface Node {
  id: string;
  description: string;
  coordenates: LatLng;
  name: string;
  status: "on" | "off" | "error";
  icon: "on" | "off" | "error" | "selected";
  positioned: boolean;
}

export type Lamp = typeof initialLamp;

export type Gateway = typeof gateway;

export interface Devices {
  nodes: Array<Lamp>;
  gateways: Array<Gateway>;
}

export interface DevicesInfo {
  totalNodes: string;
  connectedNodes: string;
  onNodes: string;
  alarmedNodes: string;
  totalGateways: string;
  connectedGateways: string;
  alarmedGateways: string;
}

export interface DevicesFilter {
  on: boolean;
  off: boolean;
  disconnected: boolean;
  alarmas: boolean;
  all: boolean;
}

export interface DetailsPopup {
  groupPopup: boolean;
  detailPopup: boolean;
}

export interface Project {
  projectName: string;
  isFavourite: boolean;
  devices: number;
}

export interface NodeDevice {
  addr: string;
  alarm_id: string;
  alarm_status: number;
  bri: number;
  gateway_addr: string;
  lamp_ctrl_id: string;
  latitude: string;
  longitude: string;
  name: string;
  on: number;
  online: number;
  orgName: string;
  organizationId: string;
  pEnergy: string;
  prjName: string;
  projectId: string;
  uid: string;
}

export interface UiData {
  isLoading: boolean;
  actualLanguage: Language;
  selectedBoundsToFly: AverageBounds;
  allowFlyMode: boolean;
}

export interface AverageBounds {
  northEast: {
    latitude: number;
    longitude: number;
  };

  southWest: {
    latitude: number;
    longitude: number;
  };
}
