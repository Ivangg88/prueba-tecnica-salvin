import styled from "styled-components";

export const DetailPopupStyled = styled.section`
  position: absolute;
  z-index: 2;
  background: rgba(255, 255, 255, 0.6);
  box-shadow: 0px 2px 5px 2px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(2px);
  border-radius: 14px;
  padding: 30px;

  .popup {
    &__button-container {
      margin: -25px;
      margin-bottom: 0;
      display: flex;
      justify-content: space-between;

      &__icon {
        font-size: 1.2rem;
        color: #686b6f;
        cursor: pointer;
      }
    }

    &__title {
      width: 100%;
      font-weight: 600;
      font-size: 1.25rem;
      color: #475569;
    }
    &__details-container {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      gap: 15px;
    }

    &__status-container {
      margin-top: 20px;
      display: flex;
      gap: 5px;
    }

    &__onoff-container {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      border-radius: 8px;
      background: #ffffff;
      border: 1px solid #c4c4c4;
      border-radius: 8px;
      height: 35px;
      padding: 0;
      margin-top: 5px;
    }

    &__link-container {
      position: absolute;
      bottom: 0;
      right: 50%;
      border-radius: 20px;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      padding: 10px 20px 10px 24px;
      gap: 8px;
      height: 45px;

      background: rgba(255, 203, 33, 1);
      transform: translate(50%, 50%);
    }
  }

  .status-container {
    &__icon {
      display: flex;
      align-items: center;
      font-size: 12px;
      color: #5e6871;
    }

    &__content {
      display: flex;
      align-items: center;
      font-size: 12px;
      color: #475569;
    }
  }

  .details-container {
    &__details {
      display: flex;
      align-items: center;
      gap: 5px;
      font-weight: 400;
      font-size: 12px;
      color: #475569;
    }

    &__icon {
      height: 100%;
      display: flex;
      align-items: center;
      font-size: 18px;
      padding-top: 2px;

      &--on {
        color: #87e897;
        font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 48;
      }

      &--alarm {
        color: #cf2a2a;
        font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 48;
      }
    }
  }

  .onoff-container {
    &__button {
      padding: 0;
      background-color: transparent;
      flex: 0.5;
      border: none;
      font-weight: 500;
      font-size: 15px;
      color: #979797;
      height: 100%;
      transition: 1000ms;
      cursor: pointer;

      &--on {
        background: #56c568;
        border-radius: 0 8px 8px 0;
        color: #ffffff;
        transform: scale(1.04);
      }

      &--off {
        background: #525252;
        border-radius: 7px 0 0 7px;
        color: #ffffff;
        transform: scale(1.04);
      }
    }
  }

  .link-container {
    &__link {
      all: unset;
      cursor: pointer;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #1b2559;
      font-weight: 500;
      font-size: 16px;
    }
  }

  .move {
    color: #bdbdbd;
    cursor: move;
  }
`;
