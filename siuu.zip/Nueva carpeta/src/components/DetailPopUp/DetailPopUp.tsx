import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useShuncomDevices } from "../../hooks/shuncom/useDevices";
import { useAppDispatch, useAppSelector } from "../../redux/hooks";
import {
  filterAlarmDevicesActionCreator,
  filterDiconnectedDevicesActionCretor,
  filteredAllDevicesActionCreator,
  filterOffDevicesActionCreator,
  filterOnDevicesActionCreator,
} from "../../redux/slices/devices/filteredDevicesSlice";
import {
  allowFlyModeActionCreator,
  setBoundsToFlyActionCreator,
} from "../../redux/slices/uiSlice/uiSlice";
import { DetailsPopup, Lamp as DeviceNode } from "../../types/interfaces";
import { initialLamp } from "../../utils/data";
import { googleIcons } from "../../utils/googleFontsIcons/icons";
import { languages } from "../../utils/languages/languages";
import { DetailPopupStyled } from "./DetailPopUpStyled";

const customWidth = 420;
const customHeight = 250;

interface DetailPopupProps {
  node: DeviceNode;
  openPopup: React.Dispatch<React.SetStateAction<DetailsPopup>>;
  setSelectedMarker: React.Dispatch<React.SetStateAction<string>>;
  setNodesGroup: React.Dispatch<React.SetStateAction<string[]>>;
}

export const DetailPopup = ({
  node,
  openPopup,
  setSelectedMarker,
  setNodesGroup,
}: DetailPopupProps) => {
  const fatherHeight = document
    .getElementById("map-container")
    ?.getBoundingClientRect().height!;
  const fatherWidth = document
    .getElementById("map-container")
    ?.getBoundingClientRect().width!;

  const initialPosition = {
    x: fatherWidth! - customWidth - 45 ?? 50,
    y: fatherHeight! / 2 - customHeight / 2 ?? 50,
  };
  const [newPosition, setNewPosition] = useState(initialPosition);
  const [origin, setOrigin] = useState({ x: 0, y: 0 });

  const dispatch = useAppDispatch();
  const devices = useAppSelector((state) => state.devices);
  const actualFilter = useAppSelector((state) => state.actualFilter);
  const currentLanguage = useAppSelector((state) => state.ui.actualLanguage);
  const { detailsPopup } = languages[currentLanguage];
  const { switchNodeStatus } = useShuncomDevices();

  const handleDragStart = (event: React.DragEvent<HTMLDivElement>) => {
    const startX = event.clientX - newPosition.x;
    const startY = event.clientY - newPosition.y;
    console.log(event.clientX, event.clientY, newPosition, startX, startY);
    setOrigin({ x: startX, y: startY });
  };

  const handleDrag = (event: React.DragEvent<HTMLDivElement>) => {
    event.currentTarget.style.setProperty("display", "none");
  };

  const handleDragEnd = (event: React.DragEvent<HTMLDivElement>) => {
    let x = event.clientX - origin.x;
    const y = event.clientY - origin.y;
    event.currentTarget.style.setProperty("display", "block");
    if (
      x > fatherWidth - customWidth ||
      y > fatherHeight - customHeight ||
      x < 0 ||
      y < 0
    ) {
      alert("Out of the map");

      return;
    }

    setNewPosition({ x, y });
  };

  const handleClick = async (order: number) => {
    //0 to off 1 to on
    try {
      await switchNodeStatus(order, node);
    } catch (error) {
      alert(error);
    }
  };
  const action = actualFilter.on
    ? filterOnDevicesActionCreator(devices)
    : actualFilter.off
    ? filterOffDevicesActionCreator(devices)
    : actualFilter.alarmas
    ? filterAlarmDevicesActionCreator(devices)
    : actualFilter.disconnected
    ? filterDiconnectedDevicesActionCretor(devices)
    : actualFilter.all
    ? filteredAllDevicesActionCreator(devices)
    : null;
  const handleClose = () => {
    openPopup({ detailPopup: false, groupPopup: false });
    setSelectedMarker(initialLamp.uid);
    setNodesGroup([]);
    if (action) dispatch(action);
    //dispatch(allowFlyModeActionCreator(true));
  };

  const {
    close,
    move,
    error,
    ligthBulb,
    connection,
    disconnection,
    arrowForward,
    location,
  } = googleIcons;

  const position = ` ${node.latitude}, 
    ${node.longitude}`;
  return (
    <DetailPopupStyled
      id="detail-popup"
      onDragStart={handleDragStart}
      onDrag={handleDrag}
      onDragEnd={handleDragEnd}
      draggable={true}
      style={{
        position: "absolute",
        height: customHeight,
        width: customWidth,
        left: `${newPosition.x}px`,
        top: `${newPosition.y}px`,
      }}
    >
      <div className="popup__button-container">
        <span className="material-symbols-rounded popup__button-container__icon move">
          {move}
        </span>
        <span
          onClick={handleClose}
          className="material-symbols-rounded popup__button-container__icon"
        >
          {close}
        </span>
      </div>

      <h1 className="popup__title">{node.name}</h1>

      <div className="popup__details-container">
        <div className="details-container__details">
          <span
            className={`material-symbols-rounded details-container__icon ${
              node.online ? "details-container__icon--on" : ""
            }`}
          >
            {node.online ? connection : disconnection}
          </span>{" "}
          <span>
            {node.online ? detailsPopup.Connected : detailsPopup.Disconnected}
          </span>
        </div>

        <div className="details-container__details">
          <span
            className={`material-symbols-rounded details-container__icon ${
              node.online && node.on ? "details-container__icon--on" : ""
            }`}
          >
            {ligthBulb}
          </span>{" "}
          <span>
            {node.online && node.on ? detailsPopup.ON : detailsPopup.OFF}
          </span>
        </div>

        <div className="details-container__details">
          <span className="material-symbols-rounded details-container__icon">
            {location}
          </span>{" "}
          <span>{position}</span>
        </div>

        <div className="details-container__details">
          <span className="material-symbols-rounded details-container__icon details-container__icon--alarm">
            {error}
          </span>{" "}
          <span>{node.alarm_status ? 1 : 0}</span>
        </div>
      </div>

      <div className="popup__status-container">
        <span className="material-symbols-rounded status-container__icon">
          {ligthBulb}
        </span>
        <span className="status-container__content">{detailsPopup.Status}</span>
      </div>

      <div className="popup__onoff-container   popup__onoff-container--off">
        <button
          onClick={() => handleClick(0)}
          className={
            !node.on || !node.online
              ? "onoff-container__button onoff-container__button--off"
              : " onoff-container__button "
          }
        >
          {detailsPopup.OFF}
        </button>
        <button
          onClick={() => handleClick(1)}
          className={
            node.on && node.online
              ? "onoff-container__button onoff-container__button--on"
              : " onoff-container__button "
          }
        >
          {detailsPopup.ON}
        </button>
      </div>

      <div className="popup__link-container">
        <NavLink to={"/detail"} className="link-container__link">
          {detailsPopup["View details"]}
          <span className="material-symbols-rounded">{arrowForward}</span>
        </NavLink>
      </div>
    </DetailPopupStyled>
  );
};
