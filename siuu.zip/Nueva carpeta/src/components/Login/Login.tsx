import { Container, LoginForm, LoginOverlay, Text } from "./LoginStyled";
import envelope_icon from "../../assets/envelope-icon.svg";
import locker_icon from "../../assets/locker-icon.svg";
import InputForm from "../Input/Input";
import { styledMainTheme } from "../../styles/styleMainTheme";
import { Button } from "../../styles/shared-styles/buttons-sizes";

interface LoginProps {
  username: string;
  password: string;
  setlogin: (newValue: boolean) => void;
  handleLogin: ({
    username,
    password,
  }: {
    username: string;
    password: string;
  }) => void;
}

export const Login = ({
  username,
  password,
  setlogin,
  handleLogin,
}: LoginProps) => {
  return (
    <Container className="login_container">
      <LoginOverlay className="overlay" />

      <div className="row">
        <div className="col-12">
          <LoginForm padding="large" className="card" borderRadius="large">
            <div className="col-12 text-center">
              <Text textType="title" fontWeight="700">
                Welcome to back
              </Text>
              <Text marginBottom="large">Sign in to your account</Text>
            </div>

            <InputForm
              preffix_icon={envelope_icon}
              inputType="email"
              placeholder="Email"
            />
            <InputForm
              preffix_icon={locker_icon}
              suffix_icon={envelope_icon}
              inputType="password"
              placeholder="Password"
              marginBottom=""
            />

            <Text
              color={styledMainTheme.light.mainIconColor}
              marginBottom="large"
              textType="caption"
            >
              Forgot Password?
            </Text>
            <div className="col-12 text-center">
              <Button
                buttonType="primary"
                onClick={() => handleLogin({ username, password })}
              >
                Sign in
              </Button>
            </div>
          </LoginForm>
        </div>
      </div>
    </Container>
  );
};
