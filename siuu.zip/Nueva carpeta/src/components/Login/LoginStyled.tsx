import styled from "styled-components";
import { BoxSizes } from "../../styles/shared-styles/box-sizes";

export const Container = styled.div`
  height: 100vh;
  width: 100%;
  overflow-x: hidden;
  /* display: flex;
  align-items: center;
  justify-content: center; */
  display: grid;
  align-content: center;
  background-size: cover;
  background-position: center;
`;

export const LoginOverlay = styled.div`
  background-color: rgba(0, 0, 0, 0.5);
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
`;

export const Text = styled(BoxSizes)`
  font-size: ${(props: {
    textType?: "title" | "subTitle" | "caption" | "";
    fontWeight?: string;
    color?: string;
  }) =>
    props.textType === "title"
      ? "28px"
      : props.textType === "subTitle"
      ? "18px"
      : props.textType === "caption"
      ? "10px"
      : "14px"};
  color: ${(props) => props.color || "#475569"};
  font-weight: ${(props) => props.fontWeight || 400};
`;

export const LoginForm = styled(BoxSizes)`
  width: 25%;
  margin: auto;
  padding: 52px;

  @media screen and (max-width: 1180px) {
    width: 50%;
  }

  @media screen and (max-width: 768px) {
    width: 90%;
  }
`;

export const InputContainer = styled(BoxSizes)`
  position: relative;
`;

export const PreffixInputIcon = styled.img`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
`;

export const SuffixInputIcon = styled.img`
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
`;

export const Input = styled.input`
  padding: ${(props) => (props.prefix ? "8px 32px" : "8px 16px")};
  border-radius: 4px;
`;
