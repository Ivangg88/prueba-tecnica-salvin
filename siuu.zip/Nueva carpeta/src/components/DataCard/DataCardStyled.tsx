import styled from "styled-components";

export const DataCardStyled = styled.section`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 10px 12px;
  gap: 10px;
  width: auto;
  background: ${(props) => props.theme.mainBackgroundColor};
  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.3),
    0px 1px 3px 1px rgba(0, 0, 0, 0.15);
  border-radius: 16px;

  .data-card {
    &__main-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 50px;
      height: 50px;
      background: ${(props) => props.theme.iconBackgroundColor};
      border-radius: 50%;

      &--alert {
        background: linear-gradient(145.39deg, #ff8686 5.72%, #ff3333 93.06%);
        color: #ff3333;
      }
    }

    &__alert-icon {
      width: 22px;
      height: 22px;
      border-radius: 50%;
      background-color: white;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 16px;
    }

    &__content-container {
      height: 50px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;

      &__title {
        text-align: start;
        margin: 0;
        font-weight: normal;
        font-size: ${(props) => props.theme.cardTitleFontSize};
        color: ${(props) => props.theme.titleFontColor};
      }

      &__content {
        margin: 0;
        font-weight: bold;
        font-size: ${(props) => props.theme.cardContentFontSize};
        color: ${(props) => props.theme.contentFontColor};
      }
    }

    &__move-icon {
      margin-bottom: -15px;
      min-height: 50px;
      color: ${(props) => props.theme.contentFontColor};
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      align-items: flex-end;
    }
  }

  h1,
  h2 {
    white-space: nowrap;
  }
`;
