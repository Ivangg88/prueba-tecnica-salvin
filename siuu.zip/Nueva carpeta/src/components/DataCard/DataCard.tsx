import { DataCardStyled } from "./DataCardStyled";

interface DataCardProps {
  mainIcon: string;
  title: string;
  content: string;
  moveIcon?: string;
  isAlert?: boolean;
}

export const DataCard = ({
  mainIcon,
  content,
  moveIcon = "arrow_right_alt",
  title,
  isAlert = false,
}: DataCardProps) => {
  return (
    <DataCardStyled>
      <span
        className={
          isAlert
            ? "material-symbols-rounded data-card__main-icon data-card__main-icon--alert"
            : "material-symbols-rounded data-card__main-icon"
        }
      >
        {!isAlert ? (
          mainIcon
        ) : (
          <span className="material-symbols-rounded data-card__alert-icon">
            priority_high
          </span>
        )}
      </span>
      <div className="data-card__content-container">
        <h2 className="data-card__content-container__title"> {title}</h2>
        <h1 className="data-card__content-container__content">{content}</h1>
      </div>
      <span className="material-symbols-rounded data-card__move-icon">
        {moveIcon}
      </span>
    </DataCardStyled>
  );
};
