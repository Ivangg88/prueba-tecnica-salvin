import { useState } from "react";
import { formatAMPM } from "../../utils/dateutils";
import { googleIcons } from "../../utils/googleFontsIcons/icons";
import { LocalWeatherStyled } from "./LocalWeatherStyled";
import { useEffect } from "react";

export const LocalWeather = () => {
  const [location, setLocation] = useState("");
  const [time, setTime] = useState(formatAMPM(new Date()));

  const actualTime = time.hours + ":" + time.formatedMinutes;
  const amPm = time.amPm.toUpperCase();

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(async (position) => {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${position.coords.latitude}&lon=${position.coords.longitude}&format=json`
      );
      const data = await response.json();
      setLocation(data.address.city + ", " + data.address.country);
    });
  }, []);

  setInterval(() => {
    setTime(formatAMPM(new Date()));
  }, 60000);

  return (
    <LocalWeatherStyled>
      <span className="material-symbols-rounded weather-card__icon">
        {googleIcons.sunny}
      </span>

      <div className="weather-card__content-container">
        <h1 className="weather-card__title">
          {location ? location : "unknown location"}
        </h1>

        <div className="weather-card__time-container">
          <h2 className="weather-card__content">{actualTime}</h2>
          <div className="weather-card__am-pm">{amPm}</div>
        </div>
      </div>
    </LocalWeatherStyled>
  );
};
