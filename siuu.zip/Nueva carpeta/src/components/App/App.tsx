import { LatLng } from "leaflet";
import { useEffect, useState } from "react";
import { ThemeProvider } from "styled-components";
import { styledMainTheme } from "../../styles/styleMainTheme";

import { CustomMap } from "../CustomMaps/CustomMap/CustomMap";
import { DataCardList } from "../DataCardList/DataCardList";
import Layout from "../Layout/Layout";
import { LocalWeather } from "../LocalWeather/LocalWeather";
import "bootstrap/dist/css/bootstrap.min.css"; // import the Bootstrap CSS file
import "bootstrap/dist/js/bootstrap.js"; // import the Bootstrap JS file
import { Login } from "../Login/Login";
import { useLoginShuncom } from "../../hooks/shuncom/useLogin";
import { credentials } from "../../utils/credentials/credentials";
import { serverCallings } from "../../utils/serverRepository/serverCallings";

type Credentials = "salviAdmin" | "arsene" | "salviLighting";

const actualuser: Credentials = "salviAdmin";

let username = credentials[actualuser].username;
let password = credentials[actualuser].password;

export const sender = new serverCallings(credentials[actualuser].url);

const initialPosition = new LatLng(0, 0);
const App = (): JSX.Element => {
  const darkTheme = false; //This variable will be changed for a ui state variable actualtheme

  const theme = darkTheme ? styledMainTheme.dark : styledMainTheme.light;

  const { loginUser } = useLoginShuncom();

  const [center, setCenter] = useState(initialPosition);

  const [login, setlogin] = useState(false);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition((position) => {
      const center = new LatLng(
        position.coords.latitude,
        position.coords.longitude
      );
      setCenter(center);
    });
  }, []);

  const handleLogin = async ({
    username,
    password,
  }: {
    username: string;
    password: string;
  }) => {
    await loginUser(username, password);
    setlogin(true);
  };

  return (
    <ThemeProvider theme={theme}>
      {login ? (
        <Layout>
          <div className="main-page">
            <DataCardList />
            <CustomMap center={center} />
            <LocalWeather />
          </div>
        </Layout>
      ) : (
        <Login
          username={username}
          password={password}
          setlogin={setlogin}
          handleLogin={handleLogin}
        />
      )}
    </ThemeProvider>
  );
};

export default App;
