import styled from "styled-components";

export const FilterByprojectStyled = styled.section`
  position: absolute;
  top: 20px;
  left: 80px;
  font-size: 16px;
  display: flex;
  flex-direction: column;
  color: ${(props) => props.theme.contentFontColor};
  justify-content: space-between;
  align-items: center;
  max-height: 300px;
  min-width: 200px;
  max-width: 200px;
  background: #ffffff;
  border-radius: 20px;
  box-shadow: 0px 4px 8px 3px rgba(0, 0, 0, 0.15);
  z-index: 1;
  gap: 5px;
  margin-right: 50px;
  cursor: default;

  .filter {
    &__title-container {
      padding: 6.4px 15px;
      width: 100%;
      display: flex;
      justify-content: space-between;
      color: inherit;
    }
  }

  .title-container {
    &__title {
      margin: 0;
      font-weight: 500;
      font-size: 14px;
      display: flex;
      align-items: center;
      color: #475569;
    }

    &__icon {
      color: inherit;
      font-weight: 400;
    }
  }

  ul {
    width: 100%;
    padding: 0;
    margin: 0;
    list-style: none;
    overflow-x: hidden;
    overflow-y: scroll;
    border-radius: 15px 0;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    background: linear-gradient(
        0deg,
        rgba(255, 255, 255, 0.08),
        rgba(255, 255, 255, 0.08)
      ),
      #ffffff;
  }

  ul::-webkit-scrollbar {
    position: absolute;
    right: 0;
    width: 3px;
    height: 50%;
  }

  ul::-webkit-scrollbar-track {
    box-shadow: inset 0 0 6px #a3aed034;
    border-radius: 5px;
  }

  ul::-webkit-scrollbar-thumb {
    background-color: rgba(169, 169, 169, 0.377);
    border-radius: 5px;
  }

  li {
    font-size: 14px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding: 0 10px 0px 5px;
  }

  li:hover {
    background-color: #f0f0f0;
  }

  .option-container {
    max-width: 80%;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    cursor: pointer;
  }

  .text {
    white-space: normal;
    text-overflow: ellipsis;
    overflow: hidden;
    font-size: 14px;
  }

  .check {
    border: 1px solid #475569;
    min-width: 10px;
    min-height: 10px;
  }

  .devices {
    align-self: center;
    font-size: 12px;
  }
`;
