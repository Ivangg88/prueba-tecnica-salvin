import { useState } from "react";
import { Project } from "../../types/interfaces";
import { FilterByprojectStyled } from "./FilterByProjectStyled";

import checked from "../../assets/icons/checked.svg";
import checkbox from "../../assets/icons/checkbox.svg";
import { useAppDispatch, useAppSelector } from "../../redux/hooks";
import {
  allowFlyModeActionCreator,
  setBoundsToFlyActionCreator,
} from "../../redux/slices/uiSlice/uiSlice";
import { getAllpositions } from "../../utils/auxiliaryFunctions";

interface FilterByProjectProps {
  projects: Project[];
  setSelectedProjects: React.Dispatch<React.SetStateAction<Array<string>>>;
  selectedProjects: Array<string>;
}

const FilterByProject = ({
  projects,
  selectedProjects,
  setSelectedProjects,
}: FilterByProjectProps) => {
  const options = projects.sort((a, b) => {
    if (a.isFavourite > b.isFavourite) {
      return -1;
    } else {
      return 1;
    }
  });

  const [showList, setShowList] = useState(false);

  const dispatch = useAppDispatch();
  const nodes = useAppSelector((state) => state.filteredDevices.nodes);

  return (
    <FilterByprojectStyled style={{ paddingBottom: showList ? "20px" : "0" }}>
      <div
        onClick={() => setShowList(!showList)}
        className="filter__title-container"
      >
        <span className="title-container__title">
          {selectedProjects.length ? selectedProjects[0] : "Groups"}
        </span>

        <span className="material-symbols-rounded title-container__icon">
          {showList ? "expand_less" : "expand_more"}
        </span>
      </div>

      {showList && (
        <ul className="list">
          <li
            onClick={() => {
              setSelectedProjects([]);
              setShowList(false);
              dispatch(allowFlyModeActionCreator(true));
            }}
          >
            <div className="option-container">
              <img
                alt="checkbox icon"
                src={
                  selectedProjects.includes("All") || !selectedProjects.length
                    ? checked
                    : checkbox
                }
              ></img>

              <span className="text"> All</span>
            </div>
          </li>

          {options.map((option) => (
            <li
              key={option.projectName}
              onClick={(event) => {
                if (!selectedProjects.includes(option.projectName)) {
                  setSelectedProjects([option.projectName]);
                } else {
                  setSelectedProjects(
                    selectedProjects.filter(
                      (name) => name !== option.projectName
                    )
                  );
                }
                // dispatch(
                //   setBoundsToFlyActionCreator(
                //     nodes.filter((node) =>
                //       selectedProjects.includes("All")
                //         ? node
                //         : selectedProjects.includes(node.prjName)
                //     )
                //   )
                // );
                dispatch(allowFlyModeActionCreator(true));
                setShowList(false);
              }}
            >
              <div className="option-container">
                <img
                  alt="checkbox icon"
                  src={
                    selectedProjects.includes(option.projectName)
                      ? checked
                      : checkbox
                  }
                ></img>

                <span className="text">{option.projectName}</span>
              </div>

              <span className="devices">{option.devices}</span>
            </li>
          ))}
        </ul>
      )}
    </FilterByprojectStyled>
  );
};

export default FilterByProject;
