import { Header } from "../Header/Header";
import { LayoutStyled } from "./LayoutStyled";
import defaultProfile from "../../assets/default-profile.png";

interface LayoutProps {
  children: JSX.Element | JSX.Element[];
}

const Layout = ({ children }: LayoutProps): JSX.Element => {
  const alerts = false;
  const projectName = "Salvi Lighting Demo";
  const breadcrumbs = projectName + "/main";

  return (
    <LayoutStyled>
      <Header
        alerts={alerts}
        breadcrums={breadcrumbs}
        projectName={projectName}
        profileImg={defaultProfile}
      ></Header>
      {children}
    </LayoutStyled>
  );
};

export default Layout;
