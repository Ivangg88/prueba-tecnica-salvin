import styled from "styled-components";

export const LayoutStyled = styled.div`
  min-width: 880px;
  height: 100vh;
  padding: 20px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  gap: 30px;
  color: ${(props) => props.theme.mainTitleColor};
  font-family: ${(props) => props.theme.mainFont};
`;
