import styled from "styled-components";

export const FilterBarStyled = styled.section`
  position: absolute;
  display: flex;
  gap: 5px;
  top: 20px;
  right: 200px;
  justify-content: center;
`;
