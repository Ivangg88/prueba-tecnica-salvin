import { useState } from "react";
import { useAppDispatch, useAppSelector } from "../../../redux/hooks";
import { setActualFilterActionCreator } from "../../../redux/slices/actualFilterSlice/actualFilterSlice";
import {
  filterAlarmDevicesActionCreator,
  filterDiconnectedDevicesActionCretor,
  filteredAllDevicesActionCreator,
  filterOffDevicesActionCreator,
  filterOnDevicesActionCreator,
} from "../../../redux/slices/devices/filteredDevicesSlice";
import { allowFlyModeActionCreator } from "../../../redux/slices/uiSlice/uiSlice";
import { DevicesFilter } from "../../../types/interfaces";
import { FilterElementStyled } from "./FilterElementStyled";

interface FilterElementProps {
  icon: string;
  title: string;
  type: "ON" | "OFF" | "Disconnected" | "Alarmed" | "All" | "button";
  customStyle: "none" | "on" | "off" | "alarmed";
}

export const FilterElement = ({
  icon,
  title,
  customStyle,
  type,
}: FilterElementProps) => {
  const [isActive, setIsActive] = useState(false);
  const dispatch = useAppDispatch();
  const filter: DevicesFilter = {
    alarmas: type === "Alarmed",
    on: type === "ON",
    off: type === "OFF",
    all: type === "All",
    disconnected: type === "Disconnected",
  };

  const devices = useAppSelector((state) => state.devices);
  const actualFilter = useAppSelector((state) => state.actualFilter);
  const filteredNodes = useAppSelector((state) => state.filteredDevices.nodes);

  const selected =
    (type === "Alarmed" && actualFilter.alarmas) ||
    (type === "All" && actualFilter.all) ||
    (type === "Disconnected" && actualFilter.disconnected) ||
    (type === "OFF" && actualFilter.off) ||
    (type === "ON" && actualFilter.on);
  const handleClick = () => {
    const action =
      type === "ON"
        ? filterOnDevicesActionCreator(devices)
        : type === "OFF"
        ? filterOffDevicesActionCreator(devices)
        : type === "Alarmed"
        ? filterAlarmDevicesActionCreator(devices)
        : type === "Disconnected"
        ? filterDiconnectedDevicesActionCretor(devices)
        : type === "All"
        ? filteredAllDevicesActionCreator(devices)
        : null;

    if (action) dispatch(action);

    setIsActive(!isActive);
    dispatch(setActualFilterActionCreator(filter));
    dispatch(allowFlyModeActionCreator(true));
  };

  return (
    <FilterElementStyled
      onClick={filteredNodes.length > 0 ? handleClick : () => {}}
    >
      <div className={selected ? "active" : ""}>
        <span className={`material-symbols-rounded icon ${customStyle}`}>
          {icon}
        </span>{" "}
        <h1>{title}</h1>
      </div>
    </FilterElementStyled>
  );
};
