import styled from "styled-components";

export const FilterElementStyled = styled.article`
  div {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    padding: 8px 12px 8px 16px;
    gap: 10px;
    background: #ffffff;
    border: 1.5px solid #a3aed0;
    border-radius: 30px;
  }

  div:hover {
    scale: calc(1.05);
  }
  h1 {
    margin: 0;
    font-weight: 500;
    font-size: 14px;
    display: flex;
    align-items: center;
    color: #475569;
  }

  .icon {
    font-size: 1rem;
  }

  .on {
    color: green;
  }

  .off,
  .alarmed {
    color: red;
  }
  .active {
    gap: 6px;
    border: 1.5px solid black;
    border-collapse: collapse;
    box-shadow: 0px 4px 8px 3px rgba(0, 0, 0, 0.15),
      0px 1px 3px rgba(0, 0, 0, 0.3);
  }

  .active > h1 {
    color: #1b2559;

    font-weight: bold;
  }
`;
