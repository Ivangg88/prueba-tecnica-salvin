import { useAppSelector } from "../../redux/hooks";
import { googleIcons } from "../../utils/googleFontsIcons/icons";
import { languages } from "../../utils/languages/languages";
import { DataCard } from "../DataCard/DataCard";
import { DataCardListStyled } from "./DataCardListStyled";

export const DataCardList = () => {
  const { ligthBulb, powerSwitch, connection, bolt } = googleIcons;
  const currentLanuguage = useAppSelector((state) => state.ui.actualLanguage);
  const { cardInfo } = languages[currentLanuguage];

  const nodes = useAppSelector((state) => state.devices.nodes);

  const connectedLuminaires =
    (
      (nodes.filter((luminaire) => luminaire.online).length * 100) /
      nodes.length
    )
      .toFixed(0)
      .toString() + "%";

  const unpositionedLuminaires = nodes
    .filter((luminaire) => !luminaire.latitude)
    .length.toString();

  const onLuminaries =
    (
      (nodes.filter((luminaire) => luminaire.on && luminaire.online).length *
        100) /
      nodes.length
    )
      .toFixed(0)
      .toString() + "%";

  const alarms = nodes
    .filter((luminaire) => luminaire.alarm_status)
    .length.toString();

  const onNodes = nodes.filter((node) => node.online && node.on);
  const totalConsumption =
    nodes.length > 1 && onNodes.length
      ? onNodes
          .map((node) => Number.parseFloat(node.pEnergy))
          .filter((pEnergy) => pEnergy)
          .reduce((accumulator, pEnergy) => (accumulator += pEnergy / 1000))
          .toFixed(2)
          .toString() + " W/h"
      : "0 W/h";

  return (
    <>
      {nodes && (
        <DataCardListStyled>
          <li className="card-container">
            <DataCard
              title={cardInfo["Total luminaires"]}
              content={nodes.length.toString()}
              mainIcon={ligthBulb}
            />
          </li>

          <li className="card-container">
            <DataCard
              title={cardInfo["Connected luminaires"]}
              content={connectedLuminaires}
              mainIcon={connection}
            />
          </li>

          <li className="card-container">
            <DataCard
              title={cardInfo["ON luminaires"]}
              mainIcon={powerSwitch}
              content={onLuminaries}
            />
          </li>

          <li className="card-container">
            <DataCard
              title={cardInfo.Alarms}
              content={alarms}
              mainIcon="no option"
              isAlert
            />
          </li>

          <li className="card-container">
            <DataCard
              title={cardInfo.Consumption}
              content={totalConsumption}
              mainIcon={bolt}
            />
          </li>

          <li className="card-container">
            <DataCard
              content={unpositionedLuminaires}
              mainIcon={"location_off"}
              title={cardInfo["Not positioned"]}
            ></DataCard>
          </li>
        </DataCardListStyled>
      )}
    </>
  );
};
