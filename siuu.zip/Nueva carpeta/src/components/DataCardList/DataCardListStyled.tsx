import styled from "styled-components";

export const DataCardListStyled = styled.ul`
  margin: 0;
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  list-style: none;
  padding: 0;
  gap: 20px;
`;
