import { LatLng } from "leaflet";
import { useMemo, useRef } from "react";
import { Marker } from "react-leaflet";
import { Marker as IMarker } from "leaflet";
import { getIcon, Status } from "../../../../utils/icons";

interface CustomMarkerOptProps {
  uid: string;
  position: { latitude: number; longitude: number };
  status: Status;
  selected: boolean;
  editable: boolean;
}

const CustomMarkerOpt = ({
  selected,
  uid,
  status,
  position,
  editable,
}: CustomMarkerOptProps) => {
  // lamp.coordenates = lamp.coordenates ? lamp.coordenates : center;
  const lampRef = useRef<IMarker>(
    new IMarker([position.latitude, position.longitude])
  );

  const icon = getIcon(status, selected);
  const positioned = position.latitude ? true : false;

  if (selected) icon.createShadow();

  return (
    <>
      <Marker
        key={uid}
        position={[position.latitude, position.longitude]}
        draggable={editable}
        riseOnHover
        riseOffset={100}
        zIndexOffset={selected || !positioned ? 150 : 0}
        icon={icon}
      ></Marker>
    </>
  );
};

export default CustomMarkerOpt;
