import styled from "styled-components";

export const CustomMapStyled = styled.section`
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  background-color: #c6cbce;
  position: relative;

  gap: 20px;

  .leaflet-container {
    min-height: 100%;
    min-width: 100%;
    z-index: 0;
  }

  .div {
    height: 20px;
    width: 100%;
    display: flex;
    justify-content: end;
    padding-right: 5px;
    background: ${(props) => props.theme.mainBackgroundColor};
    position: absolute;
    bottom: 0;
  }
`;
