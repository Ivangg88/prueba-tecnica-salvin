import "../../../styles/index.css";
import { useEffect, useState, useCallback, SyntheticEvent } from "react";
import { useMapEvents, MapContainer, TileLayer } from "react-leaflet";
import {
  DetailsPopup,
  Devices,
  DevicesFilter,
  Lamp,
  NodeDevice,
} from "../../../types/interfaces";
import CustomMarker from "../CustomMarker/CustomMarker";
import {
  featureGroup,
  LatLng,
  LatLngBounds,
  LeafletMouseEvent,
  LeafletMouseEventHandlerFn,
  Map,
  marker,
  Marker,
  polygon,
  Polygon,
} from "leaflet";
import { CustomMapStyled } from "./CustomMapStyled";
import { FilterBarStyled } from "../../FilterBar/FilterBarStyled";
import { FilterElement } from "../../FilterBar/FilterElement/FilterElement";
import { googleIcons } from "../../../utils/googleFontsIcons/icons";
import { languages } from "../../../utils/languages/languages";
import { gateway, initialLamp } from "../../../utils/data";
import { DetailPopup } from "../../DetailPopUp/DetailPopUp";
import {
  calculateDevicesInfo,
  getAllpositions,
  getAllProjects,
  getAveragePosition,
  getOneNodePerProject,
  isMarkerInsidePolygon,
  Position,
} from "../../../utils/auxiliaryFunctions";
import { GroupSelectionPopup } from "../../GroupSelectionPopup/GroupSelectionPopup";

import FilterByProject from "../../FilterByProject/FilterByProject";
import { useAppDispatch, useAppSelector } from "../../../redux/hooks";
import {
  allowFlyModeActionCreator,
  setActualLanguageActionCreator,
  setBoundsToFlyActionCreator,
} from "../../../redux/slices/uiSlice/uiSlice";
import { useLanguage } from "../../../hooks/useLanguage/useLanguage";
import { FilterElementStyled } from "../../FilterBar/FilterElement/FilterElementStyled";
import { filteredAllDevicesActionCreator } from "../../../redux/slices/devices/filteredDevicesSlice";
import CustomMarkerOpt from "./CustomMarkerOpt/CustomMarkerOpt";
import MarkerClusterGroup from "react-leaflet-cluster";
import { setActualFilterActionCreator } from "../../../redux/slices/actualFilterSlice/actualFilterSlice";

interface CustomMapProps {
  center: LatLng;
}
interface MapBounds {
  xOriginPixel: number;
  xOriginBounds: number;
  widthPixel: number;
  widthBounds: number;
  yOriginPixel: number;
  yOriginBounds: number;
  heightPixel: number;
  heightBounds: number;
}

const initialMap: MapBounds = {
  heightBounds: 0,
  heightPixel: 0,
  widthBounds: 0,
  widthPixel: 0,
  xOriginBounds: 0,
  xOriginPixel: 0,
  yOriginBounds: 0,
  yOriginPixel: 0,
};

interface MapEventHandlerProps {
  setMapBounds: React.Dispatch<React.SetStateAction<number>>;
  lamps: Array<Lamp>;

  draw: boolean;
  setDraw: React.Dispatch<React.SetStateAction<boolean>>;
  setNodesGroup: React.Dispatch<React.SetStateAction<string[]>>;
  setOpenPopUp: React.Dispatch<React.SetStateAction<DetailsPopup>>;
  positions: Array<Position>;
}

const MapEventHandler = ({
  setMapBounds,
  draw,
  setDraw,
  lamps,
  positions,
  setNodesGroup,
  setOpenPopUp,
}: MapEventHandlerProps) => {
  const [drawPolygon, setDrawPolygon] = useState(false);
  const polygonCoordinates: LatLng[] = [];
  let polygonSelection: Polygon = new Polygon(polygonCoordinates);

  const groupNodes: Array<string> = [];
  const dispatch = useAppDispatch();

  const { allowFlyMode, selectedBoundsToFly: positionsToFly } = useAppSelector(
    (state) => state.ui
  );

  const map = useMapEvents({
    load: () => {
      // setMapBounds({
      //   xOriginPixel: map.getContainer().getBoundingClientRect().left,
      //   widthPixel: map.getContainer().getBoundingClientRect().width,
      //   xOriginBounds: map.getBounds().getNorthWest().lat,
      //   widthBounds: map.getBounds().getEast() - map.getBounds().getWest(),
      //   yOriginPixel: map.getContainer().getBoundingClientRect().top,
      //   heightPixel: map.getContainer().getBoundingClientRect().height,
      //   yOriginBounds: map.getBounds().getNorthWest().lng,
      //   heightBounds: map.getBounds().getNorth() - map.getBounds().getSouth(),
      // });
    },
    locationfound: (event) => map.flyTo(event.latlng),

    click: () => {},
    zoomend: () => {
      setMapBounds(map.getZoom());
      dispatch(allowFlyModeActionCreator(false));
    },

    mousedown: () => {
      if (draw) {
        setDrawPolygon(true);
      }
      if (drawPolygon && lamps.length > 0) {
        setDrawPolygon(false);
        setDraw(false);
        map.removeLayer(polygonSelection);

        positions.forEach((position) => {
          if (isMarkerInsidePolygon(position, polygonSelection)) {
            groupNodes.push(position.id);
          }
        });

        const newLamps = lamps.filter((lamp) => groupNodes.includes(lamp.uid));
        setNodesGroup(groupNodes);
        dispatch(
          filteredAllDevicesActionCreator({ gateways: [], nodes: newLamps })
        );

        const positionToCalculate: Position[] = positions.filter((position) =>
          groupNodes.includes(position.id)
        );

        const southWest = new LatLng(
          positionToCalculate[0].latitude,
          positionToCalculate[0].longitude
        );

        const northEast = new LatLng(
          positionToCalculate[positionToCalculate.length - 1].latitude,
          positionToCalculate[positionToCalculate.length - 1].longitude
        );
        if (draw) {
          map.flyToBounds(new LatLngBounds(southWest, northEast), {
            animate: true,

            maxZoom: 18,
            padding: [50, 50],
          });
        }

        map.getZoom() > 7
          ? setOpenPopUp({ detailPopup: false, groupPopup: true })
          : setTimeout(() => {
              setOpenPopUp({ detailPopup: false, groupPopup: true });
            }, 2000);
      }
    },
    mousemove: (event) => {
      if (drawPolygon && draw) {
        map.removeLayer(polygonSelection);
        polygonCoordinates.push(event.latlng);
        polygonSelection = polygon(polygonCoordinates, {
          color: "darkblue",
          fill: true,
          fillColor: "blue",
          fillOpacity: 0.25,
          weight: 5,
        }).addTo(map);
      }
    },
  });

  const flyToPosition = useCallback(() => {
    if (positionsToFly) {
      const southWest = new LatLng(
        positionsToFly.southWest.latitude,
        positionsToFly.southWest.longitude
      );
      const northEast = new LatLng(
        positionsToFly.northEast.latitude,
        positionsToFly.northEast.longitude
      );
      map.flyToBounds(new LatLngBounds(southWest, northEast), {
        animate: true,
        maxZoom: 18,
        padding: [50, 50],
      });
    }
  }, [positionsToFly, map]);

  useEffect(() => {
    allowFlyMode && flyToPosition();
  }, [flyToPosition, allowFlyMode]);

  console.log("position filtered", positionsToFly);
  return null;
};

export const CustomMap = ({ center }: CustomMapProps) => {
  const { currentLanguage } = useLanguage();

  const devices = useAppSelector((state) => state.filteredDevices);

  const lamps = devices.nodes.filter((lamp) => lamp.latitude);

  const dispatch = useAppDispatch();

  const [map, setMap] = useState(0);
  const [selectedLamp, setSelectedLamp] = useState<string>(initialLamp.uid);
  const [openPopup, setOpenPopup] = useState<DetailsPopup>({
    groupPopup: false,
    detailPopup: false,
  });
  const [nodesGroup, setNodesGroup] = useState<Array<string>>([]);
  const [draw, setDraw] = useState(false);
  const [actualProject, setActualProject] = useState<Array<string>>([]);

  let filteredLamps: Lamp[] = lamps.filter((lamp) => {
    if (!actualProject.length) {
      return lamp;
    } else if (actualProject.includes(lamp.prjName)) return lamp;
  });

  if (!filteredLamps.length) {
    alert("No devices found");
    dispatch(
      setActualFilterActionCreator({
        alarmas: false,
        all: true,
        disconnected: false,
        off: false,
        on: false,
      })
    );
  } else {
    dispatch(setBoundsToFlyActionCreator(filteredLamps));
  }

  return (
    <CustomMapStyled id="map-container">
      <MapContainer
        center={center}
        zoom={5}
        scrollWheelZoom={true}
        maxZoom={18}
      >
        <TileLayer
          key={"map layer"}
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapEventHandler
          positions={getAllpositions(filteredLamps)}
          setOpenPopUp={setOpenPopup}
          setNodesGroup={setNodesGroup}
          lamps={filteredLamps}
          setDraw={setDraw}
          draw={draw}
          key={"map events handler"}
          setMapBounds={setMap}
        ></MapEventHandler>

        <MarkerClusterGroup
          chunkedLoading
          onClick={() => {}}
          maxClusterRadius={50}
          removeOutsideVisibleBounds
          disableClusteringAtZoom={15}
          spiderfyOnMaxZoom={false}
          zoom={10}
        >
          {filteredLamps.map((lamp) => (
            <CustomMarker
              setNodesGroup={setNodesGroup}
              openPopup={setOpenPopup}
              key={lamp.uid + Math.random().toString()}
              lamp={lamp}
              setMarker={setSelectedLamp}
              selected={selectedLamp === lamp.uid}
              editable={false}
              center={
                new LatLng(
                  Number.parseFloat(lamp.latitude),
                  Number.parseFloat(lamp.longitude)
                )
              }
            />
          ))}
        </MarkerClusterGroup>
      </MapContainer>

      {openPopup.detailPopup && devices.nodes.length && (
        <DetailPopup
          setSelectedMarker={setSelectedLamp}
          setNodesGroup={setNodesGroup}
          openPopup={setOpenPopup}
          node={filteredLamps.filter((lamp) => lamp.uid === selectedLamp)[0]}
        />
      )}

      {openPopup.groupPopup && devices.nodes.length && (
        <GroupSelectionPopup
          setSelectedMarker={setSelectedLamp}
          setSelectedGroup={setNodesGroup}
          openPopup={setOpenPopup}
          devicesInfo={calculateDevicesInfo(
            filteredLamps.filter((node) => nodesGroup.includes(node.uid)),
            [gateway]
          )}
        />
      )}

      <FilterByProject
        projects={getAllProjects(lamps)}
        selectedProjects={actualProject}
        setSelectedProjects={setActualProject}
      ></FilterByProject>
      <FilterBarStyled>
        <FilterElementStyled>
          <button
            style={{
              backgroundColor: draw ? "beige" : "",
            }}
            onClick={async () => {
              setDraw(!draw);
            }}
          >
            Select Area
          </button>
        </FilterElementStyled>
        <FilterElement
          type="All"
          customStyle="none"
          icon={googleIcons.sunny}
          title={"All"}
        />
        <FilterElement
          type="ON"
          customStyle="on"
          icon={googleIcons.ligthBulb}
          title={languages[currentLanguage].filters.ON}
        />
        <FilterElement
          type="OFF"
          customStyle="none"
          icon={googleIcons.ligthBulb}
          title={languages[currentLanguage].filters.OFF}
        />
        <FilterElement
          type="Disconnected"
          customStyle="none"
          icon={googleIcons.disconnection}
          title={languages[currentLanguage].filters.Disconnected}
        />
        <FilterElement
          type="Alarmed"
          customStyle="alarmed"
          icon={googleIcons.error}
          title={languages[currentLanguage].filters.Alarms}
        />
      </FilterBarStyled>

      <div className="div">
        <a
          rel="noreferrer"
          href="https://www.smartec.com.es/"
          target={"_blank"}
        >
          {" "}
          @Smartec
        </a>
      </div>
    </CustomMapStyled>
  );
};
