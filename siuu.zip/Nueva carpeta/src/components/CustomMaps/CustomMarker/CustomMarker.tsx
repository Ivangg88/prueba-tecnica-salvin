import { LatLng } from "leaflet";
import { useMemo, useRef } from "react";
import { Marker } from "react-leaflet";
import { DetailsPopup, Lamp } from "../../../types/interfaces";
import { Marker as IMarker } from "leaflet";
import { getIcon } from "../../../utils/icons";
import { useAppDispatch } from "../../../redux/hooks";
import {
  allowFlyModeActionCreator,
  setBoundsToFlyActionCreator,
} from "../../../redux/slices/uiSlice/uiSlice";

interface CustomMarkerProps {
  lamp: Lamp;
  selected: boolean;
  editable: boolean;
  center: LatLng;
  setMarker?: React.Dispatch<React.SetStateAction<string>>;
  openPopup?: React.Dispatch<React.SetStateAction<DetailsPopup>>;
  setNodesGroup: React.Dispatch<React.SetStateAction<string[]>>;
}

const CustomMarker = ({
  lamp,
  setMarker,
  selected,
  openPopup,
  editable,
  center,
  setNodesGroup,
}: CustomMarkerProps) => {
  // lamp.coordenates = lamp.coordenates ? lamp.coordenates : center;
  const lampRef = useRef<IMarker>(new IMarker(center));

  const lampStatus = lamp.online ? (lamp.on ? "on" : "off") : "disconnected";

  const icon = getIcon(lampStatus, selected);
  const positioned = lamp.latitude ? true : false;
  const dispatch = useAppDispatch();

  // if (selected) icon.createShadow();
  const eventHandlers = useMemo(
    () => ({
      click() {
        if (setMarker && positioned) {
          setMarker(lamp.uid);
          openPopup!({ detailPopup: true, groupPopup: false });
        }
        setNodesGroup([]);
      },
      drag() {
        if (lampRef.current && positioned) {
          lamp.latitude = lampRef.current.getLatLng().lat.toString();
          lamp.longitude = lampRef.current.getLatLng().lng.toString();
        }
      },
    }),
    [lamp, setMarker, positioned, openPopup, setNodesGroup, dispatch]
  );

  return (
    <>
      <Marker
        key={lamp.uid}
        position={center}
        draggable={editable}
        riseOnHover
        eventHandlers={eventHandlers}
        riseOffset={100}
        zIndexOffset={selected || !positioned ? 150 : 0}
        icon={icon}
      ></Marker>
    </>
  );
};

export default CustomMarker;
