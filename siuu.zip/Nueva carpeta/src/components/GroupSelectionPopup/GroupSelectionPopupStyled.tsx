import styled from "styled-components";

export const GroupSelectionPopupStyled = styled.section`
  position: absolute;
  height: auto;
  z-index: 2;
  background: rgba(255, 255, 255, 0.6);
  box-shadow: 0px 2px 5px 2px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(2px);
  border-radius: 14px;
  padding: 30px;

  .popup {
    &__button-container {
      margin: -25px;
      margin-bottom: 0;
      display: flex;
      justify-content: space-between;

      &__icon {
        font-size: 1.2rem;
        color: #686b6f;
        cursor: pointer;
      }
    }

    &__title {
      width: 100%;
      font-weight: 600;
      font-size: 1.25rem;
      color: #475569;
    }

    &__devices-selector-container {
      display: flex;
      width: 100%;
      gap: 14px;
      margin-bottom: 20px;
    }

    &__separator-container {
      display: flex;
      gap: 0;
      min-width: 100%;
      margin-bottom: 20px;
    }

    &__details-container {
      width: 100%;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      gap: 15px;
    }

    &__status-container {
      width: 100%;
      display: flex;
      gap: 15px;
      padding-left: 10px;
    }

    &__onoff-container {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      border-radius: 8px;
      background: #ffffff;
      border: 1px solid #c4c4c4;
      border-radius: 8px;
      height: 35px;
      padding: 0;
      margin-top: 5px;
    }

    &__link-container {
      position: absolute;
      bottom: 0;
      right: 50%;
      border-radius: 20px;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      padding: 10px 20px 10px 24px;
      gap: 8px;
      height: 45px;
      font-weight: 500;
      background: rgba(255, 203, 33, 1);
      transform: translate(50%, 50%);
      color: #1b2559;
    }

    &__separator {
      display: flex;
      width: 100%;
      border-top: 2px solid #d0cbd5;
      border-radius: 1px;
      margin: 30px 0;
    }

    &__bulk-actions-container {
      position: absolute;
      bottom: 15px;
      right: -25px;
      width: 215px;
      padding: 4px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      background: linear-gradient(
          0deg,
          rgba(255, 255, 255, 0.08),
          rgba(255, 255, 255, 0.08)
        ),
        #ffffff;
      box-shadow: 0px 8px 12px 6px rgba(0, 0, 0, 0.15),
        0px 4px 4px rgba(0, 0, 0, 0.3);
      border-radius: 4px;

      button {
        all: unset;
      }
    }
  }

  .devices-selector-container {
    &__device-selector {
      display: flex;
      align-items: center;
      padding: 4px 20px 4px 12px;
      gap: 10px;
      height: 30px;
      border-radius: 30px;
      white-space: nowrap;
      text-overflow: ellipsis;
      cursor: pointer;
    }

    &__device-selector--selected {
      color: white;
      background-color: #475569;
    }
  }

  .separator-container {
    &__start {
      display: flex;
      width: 15%;
      border-top: 2px solid #d0cbd5;
      border-radius: 1px;
    }

    &__icon {
      font-weight: lighter;
      color: #d0cbd5;
      display: flex;
      margin-left: -4px;
      margin-right: -4px;
      margin-top: -16px;
      transform: rotateZ(-90deg);
      font-size: 25px;
      border-radius: 1px;
    }

    &__end {
      display: flex;
      width: 85%;
      border-top: 2px solid #d0cbd5;
      border-radius: 1px;
    }
  }

  .status-container {
    &__icon {
      display: flex;
      align-items: center;
      font-size: 24px;
      color: ${(props) => props.theme.smartecGreen};
      &--alarm {
        color: #cf2a2a;
        font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 48;
      }
    }

    &__details {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      font-size: 14px;
      color: ${(props) => props.theme.mainFontColor};
    }
  }

  .details-container {
    &__details {
      display: flex;
      align-items: center;
      gap: 5px;
      font-weight: 400;
      font-size: 12px;
      color: #475569;
    }

    &__icon {
      height: 100%;
      display: flex;
      align-items: center;
      font-size: 18px;
      padding-top: 2px;

      &--on {
        color: #87e897;
        font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 48;
      }

      &--alarm {
        color: #cf2a2a;
        font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 48;
      }
    }
  }

  .link-container {
    &__link {
      all: unset;
      cursor: pointer;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #1b2559;
      font-weight: 500;
      font-size: 16px;
    }
  }

  .bulk-actions-container {
    &__action {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;
      isolation: isolate;
      padding-left: 15px;
      width: 100%;
      height: 56px;
    }

    &__action:hover {
      background-color: #1c1b1f11;
    }
  }

  .move {
    color: #bdbdbd;
    cursor: move;
  }
`;
