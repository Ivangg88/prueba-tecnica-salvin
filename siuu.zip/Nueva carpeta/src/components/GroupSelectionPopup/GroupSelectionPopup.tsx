import { useState, useCallback } from "react";
import { useShuncomDevices } from "../../hooks/shuncom/useDevices";
import { useAppDispatch, useAppSelector } from "../../redux/hooks";
import {
  filterAlarmDevicesActionCreator,
  filterDiconnectedDevicesActionCretor,
  filteredAllDevicesActionCreator,
  filterOffDevicesActionCreator,
  filterOnDevicesActionCreator,
} from "../../redux/slices/devices/filteredDevicesSlice";
import { allowFlyModeActionCreator } from "../../redux/slices/uiSlice/uiSlice";
import { DetailsPopup, DevicesInfo } from "../../types/interfaces";
import { initialLamp } from "../../utils/data";
import { googleIcons } from "../../utils/googleFontsIcons/icons";
import { languages } from "../../utils/languages/languages";
import { GroupSelectionPopupStyled } from "./GroupSelectionPopupStyled";

const customWidth = 420;
const customHeight = 460;

interface GroupSelectionPopupProps {
  devicesInfo: DevicesInfo;
  openPopup: React.Dispatch<React.SetStateAction<DetailsPopup>>;
  setSelectedGroup: React.Dispatch<React.SetStateAction<string[]>>;
  setSelectedMarker: React.Dispatch<React.SetStateAction<string>>;
}

type DevicesSelector = "nodes" | "gateways";

export const GroupSelectionPopup = ({
  devicesInfo,
  openPopup,
  setSelectedGroup,
  setSelectedMarker,
}: GroupSelectionPopupProps) => {
  const fatherHeight = document
    .getElementById("map-container")
    ?.getBoundingClientRect().height!;
  const fatherWidth = document
    .getElementById("map-container")
    ?.getBoundingClientRect().width!;

  const initialPosition = {
    x: fatherWidth! - customWidth - 45 ?? 50,
    y: fatherHeight! / 2 - customHeight / 2 ?? 50,
  };
  const { actualLanguage, allowFlyMode } = useAppSelector((state) => state.ui);
  const dispatch = useAppDispatch();
  const devices = useAppSelector((state) => state.devices);
  const filteredDevices = useAppSelector((state) => state.filteredDevices);
  const actualFilter = useAppSelector((state) => state.actualFilter);

  const [newPosition, setNewPosition] = useState(initialPosition);
  const [origin, setOrigin] = useState({ x: 0, y: 0 });
  const [actualDevices, setActualDevices] = useState<DevicesSelector>("nodes");
  const [bulkActions, setBulkActions] = useState(false);
  const [rangeInput, setRangeInput] = useState(false);
  const { detailsPopup } = languages[actualLanguage];
  const { switchNodeGroupStatus, dimmingDevices } = useShuncomDevices();

  setSelectedMarker(initialLamp.uid);

  const handleDragStart = (event: React.DragEvent<HTMLDivElement>) => {
    const startX = event.clientX - newPosition.x;
    const startY = event.clientY - newPosition.y;
    console.log(event.clientX, event.clientY, newPosition, startX, startY);
    setOrigin({ x: startX, y: startY });
  };

  const handleDrag = (event: React.DragEvent<HTMLDivElement>) => {
    event.currentTarget.style.setProperty("display", "none");
  };

  const handleDragEnd = (event: React.DragEvent<HTMLDivElement>) => {
    let x = event.clientX - origin.x;
    const y = event.clientY - origin.y;
    event.currentTarget.style.setProperty("display", "block");
    if (
      x > fatherWidth - customWidth ||
      y > fatherHeight - customHeight ||
      x < 0 ||
      y < 0
    ) {
      alert("Out of the map");
      //setNewPosition(initialPosition);
      return;
    }

    setNewPosition({ x, y });
  };

  const {
    close,
    move,
    error,
    ligthBulb,
    connection,
    disconnection,
    arrowForward,
    location,
  } = googleIcons;

  const nodesSelector = document
    .getElementById("nodes-selector")
    ?.getBoundingClientRect().width!;

  const gatewaysSelector = document
    .getElementById("gateways-selector")
    ?.getBoundingClientRect().width!;

  const selectorContainer = document
    .getElementById("selector-container")
    ?.getBoundingClientRect().width!;

  const startLineWidth =
    actualDevices === "nodes"
      ? nodesSelector / 2
      : nodesSelector + 20 + gatewaysSelector / 2;
  const endLineWidth = selectorContainer - startLineWidth;

  const lineaInicial = startLineWidth.toString() + "px";
  const lineaFinal = endLineWidth.toString() + "px";

  const action = actualFilter.on
    ? filterOnDevicesActionCreator(devices)
    : actualFilter.off
    ? filterOffDevicesActionCreator(devices)
    : actualFilter.alarmas
    ? filterAlarmDevicesActionCreator(devices)
    : actualFilter.disconnected
    ? filterDiconnectedDevicesActionCretor(devices)
    : actualFilter.all
    ? filteredAllDevicesActionCreator(devices)
    : null;

  const handleClose = useCallback(() => {
    setSelectedGroup([]);
    openPopup({ detailPopup: false, groupPopup: false });
    if (action) dispatch(action);
    dispatch(allowFlyModeActionCreator(true));
  }, [action, dispatch, openPopup, setSelectedGroup]);

  const handleBulkAction = (
    event: React.MouseEvent<HTMLSpanElement, MouseEvent>
  ) => {
    if (event.currentTarget.id === "dimming") {
      setRangeInput(true);

      return;
    }

    const order = event.currentTarget.id === "on" ? 1 : 0;

    const nodesToSwitch = filteredDevices.nodes.filter(
      (node) => node.online && (order === 1 ? !node.on : node.on)
    );

    if (filteredDevices.nodes.length === devices.nodes.length) {
      alert("All the nodes all selected!!!");
      return;
    }

    if (nodesToSwitch.length < 1) {
      alert("No selected devices");
      return;
    }
    console.log("nodes to switch", nodesToSwitch);
    switchNodeGroupStatus(order, nodesToSwitch);
    setBulkActions(false);
  };

  return (
    <GroupSelectionPopupStyled
      id="detail-popup"
      onDragStart={handleDragStart}
      onDrag={handleDrag}
      onDragEnd={handleDragEnd}
      draggable={true}
      style={{
        position: "absolute",
        height: customHeight,
        width: customWidth,
        left: `${newPosition.x}px`,
        top: `${newPosition.y}px`,
      }}
    >
      <div className="popup__button-container">
        <span className="material-symbols-rounded popup__button-container__icon move">
          {move}
        </span>
        <span
          onClick={handleClose}
          className="material-symbols-rounded popup__button-container__icon"
        >
          {close}
        </span>
      </div>

      <h1 className="popup__title">{detailsPopup["Devices selected"]}</h1>

      <div
        id="selector-container"
        className="popup__devices-selector-container"
      >
        <div
          id="nodes-selector"
          className={`devices-selector-container__device-selector ${
            actualDevices === "nodes"
              ? "devices-selector-container__device-selector--selected"
              : ""
          } `}
          onClick={() => setActualDevices("nodes")}
        >
          <span className="material-symbols-rounded">light</span>
          <span>{devicesInfo.totalNodes}</span>
        </div>

        <div
          id="gateways-selector"
          className={`devices-selector-container__device-selector ${
            actualDevices === "gateways"
              ? "devices-selector-container__device-selector--selected"
              : ""
          } `}
          onClick={() => setActualDevices("gateways")}
        >
          <span className="material-symbols-rounded">router</span>
          <span>{devicesInfo.totalGateways}</span>
        </div>
      </div>

      <div className="popup__separator-container">
        <span
          className="separator-container__start"
          style={{ width: lineaInicial }}
        ></span>
        <span className="material-symbols-rounded separator-container__icon">
          arrow_forward_ios
        </span>
        <span
          className="separator-container__end"
          style={{ width: lineaFinal }}
        ></span>
      </div>

      {actualDevices === "nodes" && (
        <>
          <div className="popup__status-container">
            <span className="material-symbols-rounded status-container__icon">
              {googleIcons.connection}
            </span>

            <div className="status-container__details">
              <span>{detailsPopup.Connection}</span>
              <span>{`${devicesInfo.connectedNodes}/${devicesInfo.totalNodes} ${detailsPopup.luminaires}`}</span>
            </div>
          </div>

          <span className="popup__separator"></span>

          <div className="popup__status-container">
            <span className="material-symbols-rounded status-container__icon">
              {googleIcons.ligthBulb}
            </span>

            <div className="status-container__details">
              <span>{detailsPopup.ON}</span>
              <span>{`${devicesInfo.onNodes}/${devicesInfo.totalNodes} ${detailsPopup.luminaires}`}</span>
            </div>
          </div>

          <span className="popup__separator"></span>

          <div className="popup__status-container">
            <span className="material-symbols-rounded status-container__icon status-container__icon--alarm ">
              {googleIcons.error}
            </span>

            <div className="status-container__details">
              <span>{detailsPopup.Alarms}</span>
              <span className="status-container__details">{`${devicesInfo.alarmedNodes}/${devicesInfo.totalNodes} ${detailsPopup.luminaires}`}</span>
            </div>
          </div>
        </>
      )}

      {actualDevices === "gateways" && (
        <>
          <div className="popup__status-container">
            <span className="material-symbols-rounded status-container__icon">
              {googleIcons.connection}
            </span>

            <div className="status-container__details">
              <span>{detailsPopup.Connection}</span>
              <span>{`${devicesInfo.connectedGateways}/${devicesInfo.totalGateways} ${detailsPopup.gateways}`}</span>
            </div>
          </div>

          <span className="popup__separator"></span>

          <div className="popup__status-container">
            <span className="material-symbols-rounded status-container__icon status-container__icon--alarm ">
              {googleIcons.error}
            </span>

            <div className="status-container__details">
              <span>{detailsPopup.Alarms}</span>
              <span className="status-container__details">{`${devicesInfo.alarmedGateways}/${devicesInfo.totalGateways} ${detailsPopup.gateways}`}</span>
            </div>
          </div>
        </>
      )}

      <div className="popup__link-container">
        <span className="material-symbols-rounded">{googleIcons.add}</span>

        <span
          onClick={() => setBulkActions(!bulkActions)}
          className="link-container__link"
        >
          {detailsPopup["Bulk actions"]}
        </span>
      </div>

      {bulkActions && (
        <article className="popup__bulk-actions-container">
          <span
            onClick={handleBulkAction}
            id="on"
            className="bulk-actions-container__action"
          >
            On all luminaires
          </span>
          <span
            onClick={handleBulkAction}
            id="off"
            className="bulk-actions-container__action"
          >
            OFF all luminaires
          </span>
          <span
            onClick={handleBulkAction}
            id="dimming"
            className="bulk-actions-container__action"
          >
            Dimming all luminaires
          </span>
        </article>
      )}
      {rangeInput && (
        <div className="popup-range-input-container popup__bulk-actions-container">
          <button
            className="bulk-actions-container__action"
            onClick={async () => {
              await dimmingDevices(25, filteredDevices.nodes);
              setBulkActions(false);
              setRangeInput(false);
            }}
          >
            dimming 25%
          </button>
          <button
            className="bulk-actions-container__action"
            onClick={async () => {
              await dimmingDevices(50, filteredDevices.nodes);
              setBulkActions(false);
              setRangeInput(false);
            }}
          >
            dimming 50%
          </button>
          <button
            className="bulk-actions-container__action"
            onClick={async () => {
              await dimmingDevices(75, filteredDevices.nodes);
              setBulkActions(false);
              setRangeInput(false);
            }}
          >
            dimming dimming 75%
          </button>

          <button
            className="bulk-actions-container__action"
            onClick={async () => {
              await dimmingDevices(100, filteredDevices.nodes);
              setBulkActions(false);
              setRangeInput(false);
            }}
          >
            dimming 100%
          </button>
          <button
            className="bulk-actions-container__action"
            onClick={async () => {
              setRangeInput(false);
            }}
          >
            back
          </button>
        </div>
      )}
    </GroupSelectionPopupStyled>
  );
};
