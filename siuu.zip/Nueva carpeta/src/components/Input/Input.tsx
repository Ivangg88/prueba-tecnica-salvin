import { useState } from "react";
import {
  InputContainer,
  PreffixInputIcon,
  SuffixInputIcon,
  Input,
} from "../Login/LoginStyled";
import visible_eye from "../../assets/envelope-icon.svg";
import invisible_eye from "../../assets/locker-icon.svg";

const InputForm = ({
  inputType = "text",
  preffix_icon = "",
  suffix_icon = "",
  placeholder = "",
  marginBottom = "medium",
}) => {
  const [visible, setVisible] = useState(false);

  const showVisibleEye = visible && inputType === "password";
  const showInvisibleEye = !visible && inputType === "password";

  return (
    <InputContainer marginBottom={marginBottom}>
      {preffix_icon && (
        <PreffixInputIcon src={preffix_icon} alt="smartec logo" height={12} />
      )}

      {suffix_icon && (
        <SuffixInputIcon
          src={
            showVisibleEye
              ? visible_eye
              : showInvisibleEye
              ? invisible_eye
              : suffix_icon
          }
          alt="smartec logo"
          height={12}
          onClick={() => setVisible(!visible)}
        />
      )}

      <Input
        prefix={preffix_icon}
        placeholder={placeholder}
        type={
          showVisibleEye ? "text" : showInvisibleEye ? "password" : inputType
        }
        className="form-control"
      />
    </InputContainer>
  );
};

export default InputForm;
