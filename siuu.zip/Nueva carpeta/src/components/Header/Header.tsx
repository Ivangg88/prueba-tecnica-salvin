import { HeaderStyled } from "./HeaderStyled";
import logo from "../../assets/smartec-logo.svg";

interface HeaderProps {
  projectName: string;
  breadcrums: string;
  profileImg: string;
  alerts: boolean;
}

export const Header = ({
  breadcrums,
  projectName,
  profileImg,
  alerts,
}: HeaderProps) => {
  return (
    <HeaderStyled className="header">
      <div className="text-content">
        <img
          className="header__logo"
          src={logo}
          alt="smartec logo"
          width={200}
        />
        <div className="header__title">
          <h2 className="header__title__breadcrumbs">{breadcrums}</h2>
          <h1 className="header__title__main">{projectName}</h1>
        </div>
      </div>

      <div className="header__toolkit">
        <span className="material-symbols-rounded header__toolkit__icon">
          work
        </span>
        <span className="material-symbols-rounded header__toolkit__icon">
          dashboard
        </span>
        <span className="material-symbols-rounded header__toolkit__icon">
          help
        </span>
        <span className="material-symbols-rounded header__toolkit__icon">
          notifications
          {alerts && <span className="alert"></span>}
        </span>
        <span className="material-symbols-rounded header__toolkit__icon">
          settings
        </span>
        <img src={profileImg} alt="profile" />
      </div>
    </HeaderStyled>
  );
};
