import styled from "styled-components";

export const HeaderStyled = styled.header`
  height: 60px;
  min-width: 880px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0;
  gap: 20px;
  width: 100%;
  font-family: ${(props) => props.theme.mainFont};
  color: ${(props) => props.theme.mainTitleColor};

  .text-content {
    height: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
  }

  .header {
    &__logo {
      width: 200px;
    }

    &__title {
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: end;
      gap: 10px;

      &__breadcrumbs {
        font-size: ${(props) => props.theme.secondFontSize};
        margin: 0;
      }

      &__main {
        font-size: ${(props) => props.theme.mainFontSize};
        margin: 0;
        line-height: 1.5rem;
      }
    }

    &__toolkit {
      width: clamp(450px, 30%, 600px);
      display: flex;
      justify-content: space-between;
      align-items: center;
      &__icon {
        position: relative;
        font-size: ${(props) => props.theme.mainIconSize};
        color: ${(props) => props.theme.mainIconColor};
      }
    }
  }
  .alert {
    position: absolute;
    top: 0px;
    right: 0px;
    width: 0.375rem;
    height: 0.375rem;
    background-color: #cf2a2a;
    border-radius: 100%;
  }
`;
