export interface ShuncomStruct {
    OperatorID: string,
    Data: string,
    TimeStamp: string,
    Seq: string,
    Sig: string
}
