export interface lampDataStruct {
    lampName: string
}
