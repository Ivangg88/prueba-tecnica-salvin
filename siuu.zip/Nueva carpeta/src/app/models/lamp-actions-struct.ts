export interface lampActionsStruct {
    off: boolean,
    on: boolean,
    dim: number,
    drag: boolean
}
